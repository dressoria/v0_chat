'use client'

import { useState } from 'react'
import { LayoutDashboard, Receipt, Calculator } from 'lucide-react'
import { AppLayout } from '@/components/layout/app-layout'
import { FinancialMetrics } from '@/components/finance/financial-metrics'
import { RevenueChart } from '@/components/finance/revenue-chart'
import { SRIPanel } from '@/components/finance/sri-panel'
import { AccountingPanel } from '@/components/finance/accounting-panel'
import { AIInsights } from '@/components/finance/ai-insights'
import { FinanceAIAssistant } from '@/components/finance/finance-ai-assistant'
import { cn } from '@/lib/utils'

type ActiveSection = 'dashboard' | 'impuestos' | 'contabilidad'

const navItems = [
  { id: 'dashboard' as const, label: 'Resumen Ejecutivo', icon: LayoutDashboard },
  { id: 'impuestos' as const, label: 'Impuestos SRI', icon: Receipt },
  { id: 'contabilidad' as const, label: 'Contabilidad', icon: Calculator }
]

export default function FinanzasPage() {
  const [activeSection, setActiveSection] = useState<ActiveSection>('dashboard')

  return (
    <AppLayout title="Finanzas" subtitle="Panel de control financiero">
      <div className="p-4 lg:p-6 space-y-6">
        {/* Section Navigation */}
        <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
          {navItems.map((item) => {
            const Icon = item.icon
            return (
              <button
                key={item.id}
                onClick={() => setActiveSection(item.id)}
                className={cn(
                  "flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium whitespace-nowrap transition-all",
                  activeSection === item.id
                    ? 'bg-gradient-to-r from-[#005EFF]/20 to-[#2200FF]/10 text-white border border-[#005EFF]/30'
                    : 'bg-slate-800/50 border border-white/10 text-gray-400 hover:text-white hover:border-[#005EFF]/50'
                )}
              >
                <Icon className={cn(
                  "h-4 w-4",
                  activeSection === item.id ? 'text-[#005EFF]' : ''
                )} />
                {item.label}
              </button>
            )
          })}
        </div>

        {/* AI Insights Banner - Always visible */}
        <AIInsights />

        {activeSection === 'dashboard' && (
          <>
            <FinancialMetrics />
            <RevenueChart />
            <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
              <SRIPanel />
              <AccountingPanel />
            </div>
          </>
        )}

        {activeSection === 'impuestos' && <SRIPanel />}

        {activeSection === 'contabilidad' && <AccountingPanel />}
      </div>

      {/* AI Assistant */}
      <FinanceAIAssistant />
    </AppLayout>
  )
}
