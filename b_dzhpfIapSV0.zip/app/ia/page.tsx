'use client'

import { Sparkles, MessageSquare, TrendingUp, Package, Receipt, Brain, Zap, BarChart3 } from 'lucide-react'
import { AppLayout } from '@/components/layout/app-layout'

const aiFeatures = [
  {
    icon: MessageSquare,
    title: 'Asistente de Ventas',
    description: 'Consulta información de productos, precios y disponibilidad en tiempo real.',
    color: '#005EFF',
    status: 'Activo'
  },
  {
    icon: TrendingUp,
    title: 'Predicción de Demanda',
    description: 'Analiza patrones de venta para predecir la demanda futura de productos.',
    color: '#2200FF',
    status: 'Activo'
  },
  {
    icon: Package,
    title: 'Optimización de Inventario',
    description: 'Sugiere niveles óptimos de stock basados en históricos de venta.',
    color: '#A200FF',
    status: 'Activo'
  },
  {
    icon: Receipt,
    title: 'Análisis Fiscal',
    description: 'Genera reportes automáticos y alertas de cumplimiento tributario.',
    color: '#005EFF',
    status: 'Beta'
  },
  {
    icon: Brain,
    title: 'Insights Financieros',
    description: 'Detecta anomalías y oportunidades en tus finanzas automáticamente.',
    color: '#2200FF',
    status: 'Activo'
  },
  {
    icon: BarChart3,
    title: 'Reportes Inteligentes',
    description: 'Genera informes personalizados con lenguaje natural.',
    color: '#A200FF',
    status: 'Próximamente'
  }
]

const recentQueries = [
  { query: '¿Cuál fue el producto más vendido esta semana?', time: 'Hace 2 horas' },
  { query: '¿Qué productos tienen stock bajo?', time: 'Hace 5 horas' },
  { query: 'Genera un resumen de ventas del mes', time: 'Ayer' },
  { query: '¿Cuánto debo declarar de IVA este mes?', time: 'Hace 2 días' },
]

export default function IAPage() {
  return (
    <AppLayout title="Centro de IA" subtitle="Asistente inteligente de negocio">
      <div className="p-4 lg:p-6 space-y-6">
        {/* Hero Section */}
        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-[#005EFF]/20 via-[#2200FF]/10 to-[#A200FF]/20 border border-white/10 p-6 lg:p-8">
          <div className="absolute top-0 right-0 w-64 h-64 bg-[#005EFF] rounded-full blur-[120px] opacity-20" />
          <div className="absolute bottom-0 left-0 w-48 h-48 bg-[#A200FF] rounded-full blur-[100px] opacity-20" />
          
          <div className="relative flex flex-col lg:flex-row items-start lg:items-center gap-6">
            <div className="p-4 rounded-2xl bg-gradient-to-br from-[#005EFF] via-[#2200FF] to-[#A200FF] shadow-lg shadow-[#005EFF]/30">
              <Sparkles className="h-8 w-8 text-white" />
            </div>
            <div className="flex-1">
              <h2 className="text-2xl font-bold text-white mb-2">Asistente de Negocio con IA</h2>
              <p className="text-gray-400 max-w-2xl">
                Potencia tu negocio con inteligencia artificial. Obtén insights, predicciones y automatiza tareas 
                repetitivas para tomar mejores decisiones.
              </p>
            </div>
            <button className="px-6 py-3 rounded-xl bg-gradient-to-r from-[#005EFF] to-[#2200FF] text-white font-semibold hover:opacity-90 transition-opacity flex items-center gap-2 shadow-lg shadow-[#005EFF]/25">
              <Zap className="h-4 w-4" />
              Iniciar Consulta
            </button>
          </div>
        </div>

        {/* Features Grid */}
        <div>
          <h3 className="text-lg font-semibold text-white mb-4">Capacidades de IA</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {aiFeatures.map((feature) => {
              const Icon = feature.icon
              return (
                <div
                  key={feature.title}
                  className="group bg-slate-900/50 backdrop-blur-xl border border-white/10 rounded-xl p-5 hover:border-white/20 transition-all cursor-pointer"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div 
                      className="p-2.5 rounded-lg"
                      style={{ backgroundColor: `${feature.color}20` }}
                    >
                      <Icon className="h-5 w-5" style={{ color: feature.color }} />
                    </div>
                    <span 
                      className={`text-[10px] font-semibold px-2 py-1 rounded-full ${
                        feature.status === 'Activo' 
                          ? 'bg-emerald-500/20 text-emerald-400'
                          : feature.status === 'Beta'
                          ? 'bg-amber-500/20 text-amber-400'
                          : 'bg-gray-500/20 text-gray-400'
                      }`}
                    >
                      {feature.status}
                    </span>
                  </div>
                  <h4 className="text-white font-semibold mb-2 group-hover:text-[#005EFF] transition-colors">
                    {feature.title}
                  </h4>
                  <p className="text-sm text-gray-400">{feature.description}</p>
                </div>
              )
            })}
          </div>
        </div>

        {/* Recent Queries */}
        <div>
          <h3 className="text-lg font-semibold text-white mb-4">Consultas Recientes</h3>
          <div className="bg-slate-900/50 backdrop-blur-xl border border-white/10 rounded-xl overflow-hidden">
            <div className="divide-y divide-white/5">
              {recentQueries.map((item, index) => (
                <div key={index} className="flex items-center justify-between p-4 hover:bg-white/5 transition-colors cursor-pointer">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-[#005EFF]/10">
                      <MessageSquare className="h-4 w-4 text-[#005EFF]" />
                    </div>
                    <span className="text-sm text-gray-300">{item.query}</span>
                  </div>
                  <span className="text-xs text-gray-500">{item.time}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  )
}
