'use client'

import { Users, UserPlus, Search, FileText, Phone, Mail } from 'lucide-react'
import { AppLayout } from '@/components/layout/app-layout'
import { Button } from '@/components/ui/button'

const mockClients = [
  { id: '0102345678001', name: 'Juan Pérez García', email: 'juan@email.com', phone: '0991234567', purchases: 15, total: 1250.00 },
  { id: '0912345678', name: 'María López Torres', email: 'maria@email.com', phone: '0987654321', purchases: 8, total: 890.50 },
  { id: '1792345678001', name: 'Comercial ABC S.A.', email: 'ventas@abc.com', phone: '042567890', purchases: 32, total: 5670.00 },
  { id: '0501234567', name: 'Carlos Mendoza', email: 'carlos@email.com', phone: '0961234567', purchases: 5, total: 320.75 },
  { id: '1891234567001', name: 'Tech Solutions Cía. Ltda.', email: 'info@tech.com', phone: '022345678', purchases: 18, total: 3450.00 },
]

export default function ClientesPage() {
  return (
    <AppLayout title="Clientes" subtitle="Gestión de clientes y contactos">
      <div className="p-4 lg:p-6 space-y-6">
        {/* Header Actions */}
        <div className="flex flex-col sm:flex-row gap-4 justify-between">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-500" />
            <input
              type="text"
              placeholder="Buscar por nombre, cédula o RUC..."
              className="w-full pl-10 pr-4 py-2.5 bg-slate-800/50 border border-white/10 rounded-xl text-sm text-white placeholder:text-gray-500 focus:outline-none focus:ring-2 focus:ring-[#005EFF]/50"
            />
          </div>
          <Button className="bg-gradient-to-r from-[#005EFF] to-[#2200FF] hover:opacity-90 border-0">
            <UserPlus className="h-4 w-4 mr-2" />
            Nuevo Cliente
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-slate-900/50 backdrop-blur-xl border border-white/10 rounded-xl p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-[#005EFF]/20">
                <Users className="h-5 w-5 text-[#005EFF]" />
              </div>
              <div>
                <p className="text-2xl font-bold text-white">248</p>
                <p className="text-xs text-gray-400">Total Clientes</p>
              </div>
            </div>
          </div>
          <div className="bg-slate-900/50 backdrop-blur-xl border border-white/10 rounded-xl p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-[#2200FF]/20">
                <UserPlus className="h-5 w-5 text-[#2200FF]" />
              </div>
              <div>
                <p className="text-2xl font-bold text-white">12</p>
                <p className="text-xs text-gray-400">Nuevos este mes</p>
              </div>
            </div>
          </div>
          <div className="bg-slate-900/50 backdrop-blur-xl border border-white/10 rounded-xl p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-[#A200FF]/20">
                <FileText className="h-5 w-5 text-[#A200FF]" />
              </div>
              <div>
                <p className="text-2xl font-bold text-white">86</p>
                <p className="text-xs text-gray-400">Con RUC</p>
              </div>
            </div>
          </div>
          <div className="bg-slate-900/50 backdrop-blur-xl border border-white/10 rounded-xl p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-emerald-500/20">
                <Users className="h-5 w-5 text-emerald-400" />
              </div>
              <div>
                <p className="text-2xl font-bold text-white">162</p>
                <p className="text-xs text-gray-400">Con Cédula</p>
              </div>
            </div>
          </div>
        </div>

        {/* Clients Table */}
        <div className="bg-slate-900/50 backdrop-blur-xl border border-white/10 rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-white/10 bg-slate-800/50">
                  <th className="text-left py-3 px-4 text-xs font-semibold text-gray-400 uppercase tracking-wider">Cliente</th>
                  <th className="text-left py-3 px-4 text-xs font-semibold text-gray-400 uppercase tracking-wider">Cédula/RUC</th>
                  <th className="text-left py-3 px-4 text-xs font-semibold text-gray-400 uppercase tracking-wider hidden md:table-cell">Contacto</th>
                  <th className="text-center py-3 px-4 text-xs font-semibold text-gray-400 uppercase tracking-wider">Compras</th>
                  <th className="text-right py-3 px-4 text-xs font-semibold text-gray-400 uppercase tracking-wider">Total</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {mockClients.map((client) => (
                  <tr key={client.id} className="hover:bg-white/5 transition-colors cursor-pointer">
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-3">
                        <div className="h-9 w-9 rounded-full bg-gradient-to-br from-[#005EFF] to-[#A200FF] flex items-center justify-center">
                          <span className="text-xs font-semibold text-white">
                            {client.name.split(' ').map(n => n[0]).slice(0, 2).join('')}
                          </span>
                        </div>
                        <span className="text-sm font-medium text-white">{client.name}</span>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <span className="text-sm text-gray-300 font-mono">{client.id}</span>
                    </td>
                    <td className="py-3 px-4 hidden md:table-cell">
                      <div className="flex flex-col gap-0.5">
                        <span className="text-xs text-gray-400 flex items-center gap-1">
                          <Mail className="h-3 w-3" /> {client.email}
                        </span>
                        <span className="text-xs text-gray-400 flex items-center gap-1">
                          <Phone className="h-3 w-3" /> {client.phone}
                        </span>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-center">
                      <span className="text-sm text-gray-300">{client.purchases}</span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <span className="text-sm font-semibold text-[#005EFF]">${client.total.toFixed(2)}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </AppLayout>
  )
}
