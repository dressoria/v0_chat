'use client'

import { useState } from 'react'
import { Package, AlertTriangle, ArrowUpDown } from 'lucide-react'
import { AppLayout } from '@/components/layout/app-layout'
import { MetricCard } from '@/components/inventory/metric-card'
import { ActionButtons } from '@/components/inventory/action-buttons'
import { InventoryTabs } from '@/components/inventory/inventory-tabs'
import { InventoryAIAssistant, InventoryAIButton } from '@/components/inventory/inventory-ai-assistant'
import { inventoryProducts, inventoryMovements } from '@/lib/inventory-data'

export default function InventarioPage() {
  const [isAIOpen, setIsAIOpen] = useState(false)

  const totalProducts = inventoryProducts.length
  const lowStockProducts = inventoryProducts.filter(p => p.quantity <= p.minStock).length
  const todayMovements = inventoryMovements.filter(m => m.date.startsWith('2024-01-15')).length

  return (
    <AppLayout title="Inventario" subtitle="Control de stock y movimientos">
      <div className="p-4 lg:p-6 space-y-6 pb-24">
        {/* Metrics Cards */}
        <section className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <MetricCard
            title="Total de Productos"
            value={totalProducts}
            icon={Package}
            variant="default"
          />
          <MetricCard
            title="Stock Bajo"
            value={lowStockProducts}
            icon={AlertTriangle}
            variant="warning"
          />
          <MetricCard
            title="Movimientos Hoy"
            value={todayMovements}
            icon={ArrowUpDown}
            variant="success"
          />
        </section>

        {/* Action Buttons */}
        <section>
          <h2 className="text-lg font-semibold text-white mb-4">Registrar Entrada</h2>
          <ActionButtons />
        </section>

        {/* Inventory Table with Tabs */}
        <section>
          <InventoryTabs />
        </section>
      </div>

      {/* AI Assistant */}
      <InventoryAIButton onClick={() => setIsAIOpen(true)} />
      <InventoryAIAssistant isOpen={isAIOpen} onClose={() => setIsAIOpen(false)} />
    </AppLayout>
  )
}
