'use client'

import { Settings, User, Building2, Printer, CreditCard, Bell, Shield, Palette } from 'lucide-react'
import { AppLayout } from '@/components/layout/app-layout'
import { cn } from '@/lib/utils'
import { useState } from 'react'

const settingSections = [
  { id: 'perfil', label: 'Perfil de Usuario', icon: User },
  { id: 'empresa', label: 'Datos de Empresa', icon: Building2 },
  { id: 'facturacion', label: 'Facturación SRI', icon: Printer },
  { id: 'pagos', label: 'Métodos de Pago', icon: CreditCard },
  { id: 'notificaciones', label: 'Notificaciones', icon: Bell },
  { id: 'seguridad', label: 'Seguridad', icon: Shield },
  { id: 'apariencia', label: 'Apariencia', icon: Palette },
]

export default function ConfiguracionPage() {
  const [activeSection, setActiveSection] = useState('perfil')

  return (
    <AppLayout title="Configuración" subtitle="Ajustes del sistema">
      <div className="p-4 lg:p-6">
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Settings Navigation */}
          <div className="lg:w-64 flex-shrink-0">
            <div className="bg-slate-900/50 backdrop-blur-xl border border-white/10 rounded-xl p-3">
              <nav className="space-y-1">
                {settingSections.map((section) => {
                  const Icon = section.icon
                  return (
                    <button
                      key={section.id}
                      onClick={() => setActiveSection(section.id)}
                      className={cn(
                        "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all text-left",
                        activeSection === section.id
                          ? 'bg-gradient-to-r from-[#005EFF]/20 to-[#2200FF]/10 text-white border border-[#005EFF]/30'
                          : 'text-gray-400 hover:text-white hover:bg-white/5'
                      )}
                    >
                      <Icon className={cn(
                        "h-4 w-4",
                        activeSection === section.id ? 'text-[#005EFF]' : ''
                      )} />
                      {section.label}
                    </button>
                  )
                })}
              </nav>
            </div>
          </div>

          {/* Settings Content */}
          <div className="flex-1">
            <div className="bg-slate-900/50 backdrop-blur-xl border border-white/10 rounded-xl p-6">
              {activeSection === 'perfil' && (
                <div className="space-y-6">
                  <h3 className="text-lg font-semibold text-white">Perfil de Usuario</h3>
                  <div className="flex items-center gap-4">
                    <div className="h-20 w-20 rounded-full bg-gradient-to-br from-[#005EFF] via-[#2200FF] to-[#A200FF] flex items-center justify-center">
                      <span className="text-2xl font-bold text-white">ML</span>
                    </div>
                    <div>
                      <button className="px-4 py-2 rounded-lg bg-[#005EFF]/20 text-[#005EFF] text-sm font-medium hover:bg-[#005EFF]/30 transition-colors">
                        Cambiar Foto
                      </button>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm text-gray-400 mb-2">Nombre</label>
                      <input
                        type="text"
                        defaultValue="María López"
                        className="w-full px-4 py-2.5 bg-slate-800/50 border border-white/10 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-[#005EFF]/50"
                      />
                    </div>
                    <div>
                      <label className="block text-sm text-gray-400 mb-2">Email</label>
                      <input
                        type="email"
                        defaultValue="maria@ventapro.com"
                        className="w-full px-4 py-2.5 bg-slate-800/50 border border-white/10 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-[#005EFF]/50"
                      />
                    </div>
                    <div>
                      <label className="block text-sm text-gray-400 mb-2">Rol</label>
                      <select className="w-full px-4 py-2.5 bg-slate-800/50 border border-white/10 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-[#005EFF]/50">
                        <option>Administrador</option>
                        <option>Cajero</option>
                        <option>Contador</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm text-gray-400 mb-2">Teléfono</label>
                      <input
                        type="tel"
                        defaultValue="0991234567"
                        className="w-full px-4 py-2.5 bg-slate-800/50 border border-white/10 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-[#005EFF]/50"
                      />
                    </div>
                  </div>
                  <div className="pt-4 border-t border-white/10">
                    <button className="px-6 py-2.5 rounded-lg bg-gradient-to-r from-[#005EFF] to-[#2200FF] text-white font-medium hover:opacity-90 transition-opacity">
                      Guardar Cambios
                    </button>
                  </div>
                </div>
              )}

              {activeSection === 'empresa' && (
                <div className="space-y-6">
                  <h3 className="text-lg font-semibold text-white">Datos de Empresa</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="md:col-span-2">
                      <label className="block text-sm text-gray-400 mb-2">Razón Social</label>
                      <input
                        type="text"
                        defaultValue="VentaPro Solutions S.A."
                        className="w-full px-4 py-2.5 bg-slate-800/50 border border-white/10 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-[#005EFF]/50"
                      />
                    </div>
                    <div>
                      <label className="block text-sm text-gray-400 mb-2">RUC</label>
                      <input
                        type="text"
                        defaultValue="1792345678001"
                        className="w-full px-4 py-2.5 bg-slate-800/50 border border-white/10 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-[#005EFF]/50"
                      />
                    </div>
                    <div>
                      <label className="block text-sm text-gray-400 mb-2">Nombre Comercial</label>
                      <input
                        type="text"
                        defaultValue="VentaPro"
                        className="w-full px-4 py-2.5 bg-slate-800/50 border border-white/10 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-[#005EFF]/50"
                      />
                    </div>
                    <div className="md:col-span-2">
                      <label className="block text-sm text-gray-400 mb-2">Dirección</label>
                      <input
                        type="text"
                        defaultValue="Av. Principal 123 y Calle Secundaria, Quito, Ecuador"
                        className="w-full px-4 py-2.5 bg-slate-800/50 border border-white/10 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-[#005EFF]/50"
                      />
                    </div>
                  </div>
                  <div className="pt-4 border-t border-white/10">
                    <button className="px-6 py-2.5 rounded-lg bg-gradient-to-r from-[#005EFF] to-[#2200FF] text-white font-medium hover:opacity-90 transition-opacity">
                      Guardar Cambios
                    </button>
                  </div>
                </div>
              )}

              {activeSection !== 'perfil' && activeSection !== 'empresa' && (
                <div className="text-center py-12">
                  <Settings className="h-12 w-12 text-gray-600 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-white mb-2">
                    {settingSections.find(s => s.id === activeSection)?.label}
                  </h3>
                  <p className="text-gray-400">Esta sección estará disponible próximamente.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  )
}
