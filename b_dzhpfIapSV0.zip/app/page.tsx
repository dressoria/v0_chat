import { POSLayout } from '@/components/pos/pos-layout'

export default function Home() {
  return <POSLayout />
}
