'use client'

import { FileText, FileSpreadsheet, Receipt, CheckCircle2, XCircle, Clock, ExternalLink } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { comprobantes } from '@/lib/finance-data'

const statusConfig = {
  autorizado: { icon: CheckCircle2, color: 'text-emerald-400', bg: 'bg-emerald-400/10', label: 'Autorizado' },
  rechazado: { icon: XCircle, color: 'text-red-400', bg: 'bg-red-400/10', label: 'Rechazado' },
  pendiente: { icon: Clock, color: 'text-amber-400', bg: 'bg-amber-400/10', label: 'Pendiente' }
}

export function SRIPanel() {
  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="rounded-xl border border-white/10 bg-white/5 backdrop-blur-md p-5">
        <div className="flex items-center gap-3 mb-4">
          <div className="p-2 rounded-lg bg-gradient-to-br from-[#005EFF] to-[#2200FF]">
            <Receipt className="h-5 w-5 text-white" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-white">Gestión Tributaria SRI</h3>
            <p className="text-sm text-gray-400">Ecuador - Facturación Electrónica</p>
          </div>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <Button 
            className="h-auto py-4 bg-gradient-to-r from-[#005EFF] to-[#2200FF] hover:from-[#0050DD] hover:to-[#1D00DD] text-white border-0 flex flex-col items-center gap-2"
          >
            <FileSpreadsheet className="h-5 w-5" />
            <span className="text-sm font-medium">Generar ATS</span>
            <span className="text-xs text-white/70">Anexo Transaccional</span>
          </Button>
          
          <Button 
            className="h-auto py-4 bg-gradient-to-r from-[#2200FF] to-[#A200FF] hover:from-[#1D00DD] hover:to-[#8800DD] text-white border-0 flex flex-col items-center gap-2"
          >
            <FileText className="h-5 w-5" />
            <span className="text-sm font-medium">Formulario 104</span>
            <span className="text-xs text-white/70">Proyección IVA</span>
          </Button>
          
          <Button 
            className="h-auto py-4 bg-gradient-to-r from-[#A200FF] to-[#005EFF] hover:from-[#8800DD] hover:to-[#0050DD] text-white border-0 flex flex-col items-center gap-2"
          >
            <Receipt className="h-5 w-5" />
            <span className="text-sm font-medium">Formulario 103</span>
            <span className="text-xs text-white/70">Retenciones</span>
          </Button>
        </div>
      </div>

      {/* Comprobantes Table */}
      <div className="rounded-xl border border-white/10 bg-white/5 backdrop-blur-md p-5">
        <div className="flex items-center justify-between mb-4">
          <h4 className="font-semibold text-white">Comprobantes Electrónicos Recientes</h4>
          <Button variant="ghost" size="sm" className="text-[#005EFF] hover:text-[#005EFF]/80 hover:bg-[#005EFF]/10">
            Ver todos <ExternalLink className="h-3 w-3 ml-1" />
          </Button>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-white/10">
                <th className="text-left py-3 px-2 text-gray-400 font-medium">Tipo</th>
                <th className="text-left py-3 px-2 text-gray-400 font-medium">Número</th>
                <th className="text-left py-3 px-2 text-gray-400 font-medium hidden md:table-cell">Cliente</th>
                <th className="text-right py-3 px-2 text-gray-400 font-medium">Monto</th>
                <th className="text-center py-3 px-2 text-gray-400 font-medium">Estado</th>
              </tr>
            </thead>
            <tbody>
              {comprobantes.map((comp) => {
                const status = statusConfig[comp.estado]
                const StatusIcon = status.icon
                return (
                  <tr key={comp.id} className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="py-3 px-2 text-white">{comp.tipo}</td>
                    <td className="py-3 px-2 text-gray-300 font-mono text-xs">{comp.numero}</td>
                    <td className="py-3 px-2 text-gray-300 hidden md:table-cell">{comp.cliente}</td>
                    <td className="py-3 px-2 text-white text-right font-medium">
                      ${comp.monto.toLocaleString('es-EC', { minimumFractionDigits: 2 })}
                    </td>
                    <td className="py-3 px-2">
                      <div className={`inline-flex items-center gap-1 px-2 py-1 rounded-full ${status.bg} ${status.color} text-xs font-medium`}>
                        <StatusIcon className="h-3 w-3" />
                        {status.label}
                      </div>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
