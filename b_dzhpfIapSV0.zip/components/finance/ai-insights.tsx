'use client'

import { Sparkles, AlertTriangle, CheckCircle2, Info, ArrowRight } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { aiInsights } from '@/lib/finance-data'

const typeConfig = {
  warning: { icon: AlertTriangle, color: 'text-amber-400', bg: 'from-amber-500/20 to-amber-600/5', border: 'border-amber-500/30' },
  success: { icon: CheckCircle2, color: 'text-emerald-400', bg: 'from-emerald-500/20 to-emerald-600/5', border: 'border-emerald-500/30' },
  info: { icon: Info, color: 'text-[#005EFF]', bg: 'from-[#005EFF]/20 to-[#2200FF]/5', border: 'border-[#005EFF]/30' }
}

export function AIInsights() {
  return (
    <div className="rounded-xl border border-white/10 bg-gradient-to-br from-[#005EFF]/10 via-[#2200FF]/5 to-[#A200FF]/10 backdrop-blur-md p-5 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 right-0 w-40 h-40 bg-gradient-to-br from-[#005EFF]/20 to-[#A200FF]/20 rounded-full blur-3xl" />
      
      <div className="relative">
        <div className="flex items-center gap-3 mb-4">
          <div className="p-2 rounded-lg bg-gradient-to-br from-[#005EFF] to-[#A200FF]">
            <Sparkles className="h-5 w-5 text-white" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-white">Insights de la IA</h3>
            <p className="text-sm text-gray-400">Análisis inteligente de tu negocio</p>
          </div>
        </div>

        <div className="space-y-3">
          {aiInsights.map((insight) => {
            const config = typeConfig[insight.type]
            const Icon = config.icon
            return (
              <div 
                key={insight.id} 
                className={`rounded-lg border ${config.border} bg-gradient-to-r ${config.bg} p-4`}
              >
                <div className="flex items-start gap-3">
                  <Icon className={`h-5 w-5 ${config.color} flex-shrink-0 mt-0.5`} />
                  <div className="flex-1">
                    <p className="text-sm text-gray-200 leading-relaxed">{insight.message}</p>
                    {insight.action && (
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className={`mt-2 ${config.color} hover:bg-white/10 p-0 h-auto font-medium`}
                      >
                        {insight.action} <ArrowRight className="h-3 w-3 ml-1" />
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}
