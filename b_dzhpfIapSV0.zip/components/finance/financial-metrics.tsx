'use client'

import { Wallet, TrendingUp, TrendingDown, ArrowUpRight, ArrowDownRight } from 'lucide-react'
import { financialMetrics } from '@/lib/finance-data'

const iconMap: Record<string, React.ReactNode> = {
  'wallet': <Wallet className="h-5 w-5" />,
  'arrow-up': <ArrowUpRight className="h-5 w-5" />,
  'arrow-down': <ArrowDownRight className="h-5 w-5" />,
  'trending-up': <TrendingUp className="h-5 w-5" />
}

export function FinancialMetrics() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
      {financialMetrics.map((metric) => (
        <div 
          key={metric.id}
          className="relative overflow-hidden rounded-xl border border-white/10 bg-white/5 backdrop-blur-md p-5"
        >
          {/* Gradient accent */}
          <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-br from-[#005EFF]/20 to-[#A200FF]/20 rounded-full blur-2xl" />
          
          <div className="relative">
            <div className="flex items-center justify-between mb-3">
              <div className="p-2 rounded-lg bg-gradient-to-br from-[#005EFF]/20 to-[#2200FF]/20 text-[#005EFF]">
                {iconMap[metric.icon]}
              </div>
              <div className={`flex items-center gap-1 text-sm font-medium ${
                metric.changeType === 'positive' ? 'text-emerald-400' : 
                metric.changeType === 'negative' ? 'text-red-400' : 'text-gray-400'
              }`}>
                {metric.changeType === 'positive' ? (
                  <TrendingUp className="h-3 w-3" />
                ) : metric.changeType === 'negative' ? (
                  <TrendingDown className="h-3 w-3" />
                ) : null}
                {metric.change > 0 ? '+' : ''}{metric.change}%
              </div>
            </div>
            
            <p className="text-sm text-gray-400 mb-1">{metric.label}</p>
            <p className="text-2xl font-bold text-white">
              ${metric.value.toLocaleString('es-EC', { minimumFractionDigits: 2 })}
            </p>
          </div>
        </div>
      ))}
    </div>
  )
}
