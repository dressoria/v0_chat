'use client'

import { useState } from 'react'
import { ChevronRight, ChevronDown, FolderTree, BookOpen, Scale, FileBarChart, Plus, FileText } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { planCuentas, asientosRecientes } from '@/lib/finance-data'
import type { CuentaContable } from '@/lib/finance-types'

function CuentaItem({ cuenta, level = 0 }: { cuenta: CuentaContable; level?: number }) {
  const [isOpen, setIsOpen] = useState(level < 2)
  const hasChildren = cuenta.children && cuenta.children.length > 0

  return (
    <div>
      <div 
        className={`flex items-center justify-between py-2 px-3 hover:bg-white/5 rounded-lg cursor-pointer transition-colors ${level === 0 ? 'bg-white/5' : ''}`}
        style={{ paddingLeft: `${level * 16 + 12}px` }}
        onClick={() => hasChildren && setIsOpen(!isOpen)}
      >
        <div className="flex items-center gap-2">
          {hasChildren ? (
            isOpen ? <ChevronDown className="h-4 w-4 text-gray-400" /> : <ChevronRight className="h-4 w-4 text-gray-400" />
          ) : (
            <div className="w-4" />
          )}
          <span className="text-[#005EFF] font-mono text-sm">{cuenta.codigo}</span>
          <span className={`text-sm ${level === 0 ? 'font-semibold text-white' : 'text-gray-300'}`}>
            {cuenta.nombre}
          </span>
        </div>
        <span className={`font-medium text-sm ${cuenta.saldo >= 0 ? 'text-white' : 'text-red-400'}`}>
          ${Math.abs(cuenta.saldo).toLocaleString('es-EC', { minimumFractionDigits: 2 })}
        </span>
      </div>
      {hasChildren && isOpen && (
        <div>
          {cuenta.children!.map((child) => (
            <CuentaItem key={child.id} cuenta={child} level={level + 1} />
          ))}
        </div>
      )}
    </div>
  )
}

export function AccountingPanel() {
  const [activeTab, setActiveTab] = useState<'plan' | 'diario'>('plan')

  return (
    <div className="space-y-4">
      {/* Quick Actions */}
      <div className="rounded-xl border border-white/10 bg-white/5 backdrop-blur-md p-5">
        <h3 className="text-lg font-semibold text-white mb-4">Contabilidad General</h3>
        
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
          <Button 
            variant="outline" 
            className="h-auto py-3 flex flex-col items-center gap-2 border-white/10 bg-white/5 hover:bg-[#005EFF]/10 hover:border-[#005EFF]/50 text-white hover:text-white"
          >
            <FolderTree className="h-5 w-5 text-[#005EFF]" />
            <span className="text-xs">Plan de Cuentas</span>
          </Button>
          
          <Button 
            variant="outline" 
            className="h-auto py-3 flex flex-col items-center gap-2 border-white/10 bg-white/5 hover:bg-[#2200FF]/10 hover:border-[#2200FF]/50 text-white hover:text-white"
          >
            <BookOpen className="h-5 w-5 text-[#2200FF]" />
            <span className="text-xs">Libro Diario</span>
          </Button>
          
          <Button 
            variant="outline" 
            className="h-auto py-3 flex flex-col items-center gap-2 border-white/10 bg-white/5 hover:bg-[#A200FF]/10 hover:border-[#A200FF]/50 text-white hover:text-white"
          >
            <Scale className="h-5 w-5 text-[#A200FF]" />
            <span className="text-xs">Balance General</span>
          </Button>
          
          <Button 
            variant="outline" 
            className="h-auto py-3 flex flex-col items-center gap-2 border-white/10 bg-white/5 hover:bg-[#005EFF]/10 hover:border-[#005EFF]/50 text-white hover:text-white"
          >
            <FileBarChart className="h-5 w-5 text-[#005EFF]" />
            <span className="text-xs">Estado Resultados</span>
          </Button>
        </div>

        <Button className="w-full bg-gradient-to-r from-[#005EFF] to-[#2200FF] hover:from-[#0050DD] hover:to-[#1D00DD] text-white">
          <Plus className="h-4 w-4 mr-2" />
          Nuevo Asiento Contable Manual
        </Button>
      </div>

      {/* Plan de Cuentas / Libro Diario Tabs */}
      <div className="rounded-xl border border-white/10 bg-white/5 backdrop-blur-md overflow-hidden">
        <div className="flex border-b border-white/10">
          <button
            onClick={() => setActiveTab('plan')}
            className={`flex-1 px-4 py-3 text-sm font-medium transition-colors ${
              activeTab === 'plan' 
                ? 'bg-[#005EFF]/10 text-[#005EFF] border-b-2 border-[#005EFF]' 
                : 'text-gray-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <FolderTree className="h-4 w-4 inline mr-2" />
            Plan de Cuentas
          </button>
          <button
            onClick={() => setActiveTab('diario')}
            className={`flex-1 px-4 py-3 text-sm font-medium transition-colors ${
              activeTab === 'diario' 
                ? 'bg-[#005EFF]/10 text-[#005EFF] border-b-2 border-[#005EFF]' 
                : 'text-gray-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <FileText className="h-4 w-4 inline mr-2" />
            Libro Diario
          </button>
        </div>

        <div className="p-4 max-h-[400px] overflow-y-auto">
          {activeTab === 'plan' ? (
            <div className="space-y-1">
              {planCuentas.map((cuenta) => (
                <CuentaItem key={cuenta.id} cuenta={cuenta} />
              ))}
            </div>
          ) : (
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-white/10">
                  <th className="text-left py-2 px-2 text-gray-400 font-medium">Fecha</th>
                  <th className="text-left py-2 px-2 text-gray-400 font-medium">Cuenta</th>
                  <th className="text-right py-2 px-2 text-gray-400 font-medium">Debe</th>
                  <th className="text-right py-2 px-2 text-gray-400 font-medium">Haber</th>
                </tr>
              </thead>
              <tbody>
                {asientosRecientes.map((asiento) => (
                  <tr key={asiento.id} className="border-b border-white/5">
                    <td className="py-2 px-2 text-gray-400 text-xs">{asiento.fecha}</td>
                    <td className="py-2 px-2">
                      <p className="text-white text-xs">{asiento.cuenta}</p>
                      <p className="text-gray-500 text-xs truncate max-w-[200px]">{asiento.descripcion}</p>
                    </td>
                    <td className="py-2 px-2 text-right text-white font-mono">
                      {asiento.debe > 0 ? `$${asiento.debe.toLocaleString('es-EC', { minimumFractionDigits: 2 })}` : ''}
                    </td>
                    <td className="py-2 px-2 text-right text-white font-mono">
                      {asiento.haber > 0 ? `$${asiento.haber.toLocaleString('es-EC', { minimumFractionDigits: 2 })}` : ''}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  )
}
