'use client'

import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts'
import { monthlyData } from '@/lib/finance-data'

export function RevenueChart() {
  return (
    <div className="rounded-xl border border-white/10 bg-white/5 backdrop-blur-md p-5">
      <div className="mb-4">
        <h3 className="text-lg font-semibold text-white">Ingresos vs Egresos</h3>
        <p className="text-sm text-gray-400">Comparativa mensual del año fiscal</p>
      </div>
      
      <div className="h-[300px] w-full">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={monthlyData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
            <defs>
              <linearGradient id="colorIngresos" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#005EFF" stopOpacity={0.4}/>
                <stop offset="95%" stopColor="#005EFF" stopOpacity={0}/>
              </linearGradient>
              <linearGradient id="colorEgresos" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#A200FF" stopOpacity={0.4}/>
                <stop offset="95%" stopColor="#A200FF" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
            <XAxis 
              dataKey="month" 
              stroke="#9ca3af" 
              fontSize={12}
              tickLine={false}
              axisLine={false}
            />
            <YAxis 
              stroke="#9ca3af" 
              fontSize={12}
              tickLine={false}
              axisLine={false}
              tickFormatter={(value) => `$${(value / 1000).toFixed(0)}k`}
            />
            <Tooltip 
              contentStyle={{
                backgroundColor: 'rgba(15, 23, 42, 0.95)',
                border: '1px solid rgba(255,255,255,0.1)',
                borderRadius: '12px',
                color: '#fff'
              }}
              formatter={(value: number) => [`$${value.toLocaleString()}`, '']}
            />
            <Legend 
              wrapperStyle={{ color: '#9ca3af' }}
            />
            <Area 
              type="monotone" 
              dataKey="ingresos" 
              stroke="#005EFF" 
              strokeWidth={2}
              fillOpacity={1} 
              fill="url(#colorIngresos)" 
              name="Ingresos"
            />
            <Area 
              type="monotone" 
              dataKey="egresos" 
              stroke="#A200FF" 
              strokeWidth={2}
              fillOpacity={1} 
              fill="url(#colorEgresos)" 
              name="Egresos"
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}
