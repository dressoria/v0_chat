'use client'

import { useState } from 'react'
import { BrainCircuit, X, Send, BarChart3, Sparkles } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'

interface Message {
  id: string
  role: 'user' | 'assistant'
  content: string
}

const quickQuestions = [
  '¿Cuál es mi rentabilidad este mes?',
  '¿Qué clientes tienen facturas vencidas?',
  'Proyección de IVA a pagar',
  'Resumen de gastos por categoría'
]

export function FinanceAIAssistant() {
  const [isOpen, setIsOpen] = useState(false)
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content: '¡Hola! Soy tu asistente financiero con IA. Puedo ayudarte a analizar tus finanzas, generar reportes, proyectar impuestos y mucho más. ¿Qué necesitas consultar?'
    }
  ])
  const [input, setInput] = useState('')

  const handleSend = () => {
    if (!input.trim()) return
    
    const newMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input
    }
    
    setMessages(prev => [...prev, newMessage])
    setInput('')
    
    // Simulate AI response
    setTimeout(() => {
      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: 'Analizando tu consulta... En este momento estoy procesando los datos financieros de tu empresa. Esta funcionalidad estará completamente disponible cuando conectes tu base de datos.'
      }
      setMessages(prev => [...prev, aiResponse])
    }, 1000)
  }

  const handleQuickQuestion = (question: string) => {
    setInput(question)
  }

  return (
    <>
      {/* Floating Button */}
      <button
        onClick={() => setIsOpen(true)}
        className={`fixed bottom-6 right-6 z-50 p-4 rounded-2xl bg-gradient-to-r from-[#005EFF] via-[#2200FF] to-[#A200FF] text-white shadow-lg shadow-[#005EFF]/30 hover:shadow-[#005EFF]/50 transition-all duration-300 hover:scale-105 ${isOpen ? 'hidden' : 'flex'} items-center gap-3`}
      >
        <div className="relative">
          <BrainCircuit className="h-6 w-6" />
          <span className="absolute -top-1 -right-1 flex h-3 w-3">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75"></span>
            <span className="relative inline-flex rounded-full h-3 w-3 bg-white"></span>
          </span>
        </div>
        <span className="font-medium hidden sm:inline">IA Financiera</span>
      </button>

      {/* Chat Window */}
      {isOpen && (
        <div className="fixed bottom-6 right-6 z-50 w-[380px] max-w-[calc(100vw-48px)] h-[550px] max-h-[calc(100vh-100px)] rounded-2xl border border-white/10 bg-slate-900/95 backdrop-blur-xl shadow-2xl shadow-black/50 flex flex-col overflow-hidden">
          {/* Header */}
          <div className="flex-shrink-0 p-4 border-b border-white/10 bg-gradient-to-r from-[#005EFF]/10 via-[#2200FF]/10 to-[#A200FF]/10">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-xl bg-gradient-to-r from-[#005EFF] to-[#A200FF]">
                  <BrainCircuit className="h-5 w-5 text-white" />
                </div>
                <div>
                  <h3 className="font-semibold text-white">IA Financiera</h3>
                  <p className="text-xs text-gray-400">Asistente Contable Inteligente</p>
                </div>
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsOpen(false)}
                className="text-gray-400 hover:text-white hover:bg-white/10"
              >
                <X className="h-5 w-5" />
              </Button>
            </div>
          </div>

          {/* Quick Questions */}
          <div className="flex-shrink-0 p-3 border-b border-white/10 overflow-x-auto scrollbar-hide">
            <div className="flex gap-2">
              {quickQuestions.map((q, i) => (
                <button
                  key={i}
                  onClick={() => handleQuickQuestion(q)}
                  className="flex-shrink-0 px-3 py-1.5 text-xs rounded-full border border-white/10 bg-white/5 text-gray-300 hover:bg-[#005EFF]/20 hover:border-[#005EFF]/50 hover:text-white transition-colors"
                >
                  {q}
                </button>
              ))}
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[85%] rounded-2xl px-4 py-3 ${
                    message.role === 'user'
                      ? 'bg-gradient-to-r from-[#005EFF] to-[#2200FF] text-white'
                      : 'bg-white/10 text-gray-200 border border-white/10'
                  }`}
                >
                  {message.role === 'assistant' && (
                    <div className="flex items-center gap-2 mb-1">
                      <Sparkles className="h-3 w-3 text-[#005EFF]" />
                      <span className="text-xs text-[#005EFF] font-medium">IA Financiera</span>
                    </div>
                  )}
                  <p className="text-sm leading-relaxed">{message.content}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Input */}
          <div className="flex-shrink-0 p-4 border-t border-white/10 bg-slate-900/50">
            <div className="flex items-center gap-2">
              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Pregunta sobre tus finanzas..."
                className="flex-1 bg-white/5 border-white/10 text-white placeholder:text-gray-500 focus-visible:ring-[#005EFF]/50 focus-visible:border-[#005EFF]/50"
              />
              <Button 
                onClick={handleSend}
                size="icon"
                className="bg-gradient-to-r from-[#005EFF] to-[#2200FF] hover:from-[#0050DD] hover:to-[#1D00DD] text-white"
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
