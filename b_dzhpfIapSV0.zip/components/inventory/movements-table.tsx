'use client'

import { inventoryMovements, getMovementTypeLabel, getMovementTypeColor } from '@/lib/inventory-data'
import { cn } from '@/lib/utils'

export function MovementsTable() {
  return (
    <div className="overflow-x-auto">
      <table className="w-full">
        <thead>
          <tr className="border-b border-white/10">
            <th className="text-left py-4 px-4 text-sm font-medium text-slate-400">Fecha</th>
            <th className="text-left py-4 px-4 text-sm font-medium text-slate-400">Tipo</th>
            <th className="text-left py-4 px-4 text-sm font-medium text-slate-400 hidden sm:table-cell">Producto</th>
            <th className="text-right py-4 px-4 text-sm font-medium text-slate-400">Cantidad</th>
            <th className="text-left py-4 px-4 text-sm font-medium text-slate-400 hidden md:table-cell">Usuario</th>
          </tr>
        </thead>
        <tbody>
          {inventoryMovements.map((movement) => (
            <tr 
              key={movement.id} 
              className="border-b border-white/5 hover:bg-white/5 transition-colors"
            >
              <td className="py-4 px-4 text-slate-400 text-sm">
                {movement.date}
              </td>
              <td className="py-4 px-4">
                <span className={cn(
                  "px-2.5 py-1 rounded-lg text-xs font-medium",
                  movement.type === 'purchase' && "bg-emerald-500/20 text-emerald-400",
                  movement.type === 'sale' && "bg-cyan-500/20 text-cyan-400",
                  movement.type === 'adjustment' && "bg-amber-500/20 text-amber-400",
                  movement.type === 'loss' && "bg-red-500/20 text-red-400"
                )}>
                  {getMovementTypeLabel(movement.type)}
                </span>
              </td>
              <td className="py-4 px-4 text-white hidden sm:table-cell">
                {movement.productName}
              </td>
              <td className="py-4 px-4 text-right">
                <span className={cn(
                  "font-semibold",
                  movement.quantity > 0 ? "text-emerald-400" : "text-red-400"
                )}>
                  {movement.quantity > 0 ? '+' : ''}{movement.quantity}
                </span>
              </td>
              <td className="py-4 px-4 text-slate-400 text-sm hidden md:table-cell">
                {movement.user}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
