'use client'

import { useState } from 'react'
import { cn } from '@/lib/utils'
import { StockTable } from './stock-table'
import { MovementsTable } from './movements-table'
import { Package, History } from 'lucide-react'

type TabType = 'stock' | 'movements'

export function InventoryTabs() {
  const [activeTab, setActiveTab] = useState<TabType>('stock')

  return (
    <div className="rounded-2xl bg-white/5 backdrop-blur-xl border border-white/10 overflow-hidden">
      {/* Tab Headers */}
      <div className="flex border-b border-white/10">
        <button
          onClick={() => setActiveTab('stock')}
          className={cn(
            "flex-1 flex items-center justify-center gap-2 py-4 px-6 text-sm font-medium transition-all",
            activeTab === 'stock'
              ? "text-white bg-white/10 border-b-2 border-[#005EFF]"
              : "text-slate-400 hover:text-white hover:bg-white/5"
          )}
        >
          <Package className="h-4 w-4" />
          Stock Actual
        </button>
        <button
          onClick={() => setActiveTab('movements')}
          className={cn(
            "flex-1 flex items-center justify-center gap-2 py-4 px-6 text-sm font-medium transition-all",
            activeTab === 'movements'
              ? "text-white bg-white/10 border-b-2 border-[#A200FF]"
              : "text-slate-400 hover:text-white hover:bg-white/5"
          )}
        >
          <History className="h-4 w-4" />
          Historial de Movimientos
        </button>
      </div>

      {/* Tab Content */}
      <div className="p-2 sm:p-4">
        {activeTab === 'stock' ? <StockTable /> : <MovementsTable />}
      </div>
    </div>
  )
}
