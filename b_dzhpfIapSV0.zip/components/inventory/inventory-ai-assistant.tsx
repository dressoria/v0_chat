'use client'

import { useState } from 'react'
import { X, Send, Sparkles, Bot } from 'lucide-react'
import { cn } from '@/lib/utils'

interface Message {
  id: string
  role: 'user' | 'assistant'
  content: string
}

interface InventoryAIAssistantProps {
  isOpen: boolean
  onClose: () => void
}

export function InventoryAIAssistant({ isOpen, onClose }: InventoryAIAssistantProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content: '¡Hola! Soy tu asistente de inventario con IA. Puedo ayudarte a analizar tu stock, predecir necesidades de reabastecimiento, detectar productos de baja rotación y mucho más. ¿Qué necesitas consultar?'
    }
  ])
  const [input, setInput] = useState('')

  const handleSend = () => {
    if (!input.trim()) return

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input
    }

    setMessages((prev) => [...prev, userMessage])
    setInput('')

    setTimeout(() => {
      const responses = [
        'Detecté que tienes 3 productos con stock crítico: Crema Anti-edad (5 unidades), Sérum Vitamina C (8 unidades) y Colágeno (3 unidades). Te recomiendo hacer pedido esta semana.',
        'Basado en tu historial de ventas, la Proteína Whey tiene una rotación de 12 días. Con el stock actual de 24 unidades, deberías reabastecer en aproximadamente 2 semanas.',
        'El costo promedio de tu inventario ha aumentado un 8% este mes. Los suplementos son la categoría con mayor incremento (+12%).',
        'Tus productos de cuidado de piel tienen el margen más alto (42%) pero la rotación más lenta. Considera promociones para acelerar ventas.',
        'He identificado que el Colágeno Hidrolizado tiene alta demanda pero bajo stock. Históricamente vendes 4-5 unidades por semana.'
      ]
      
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: responses[Math.floor(Math.random() * responses.length)]
      }
      
      setMessages((prev) => [...prev, assistantMessage])
    }, 1000)
  }

  return (
    <>
      {/* Overlay */}
      <div
        className={cn(
          'fixed inset-0 bg-black/60 backdrop-blur-sm z-40 transition-opacity duration-300',
          isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
        )}
        onClick={onClose}
      />

      {/* Chat Window */}
      <div
        className={cn(
          'fixed z-50 rounded-2xl shadow-2xl transition-all duration-300 ease-out',
          'bottom-24 right-4 w-[calc(100%-2rem)] max-w-md h-[70vh] max-h-[500px]',
          'md:bottom-24 md:right-6 md:w-96',
          'bg-slate-900/95 backdrop-blur-xl border border-white/10',
          isOpen ? 'translate-y-0 opacity-100' : 'translate-y-8 opacity-0 pointer-events-none'
        )}
      >
        {/* Header */}
        <div 
          className="flex items-center justify-between p-4 border-b border-white/10 rounded-t-2xl"
          style={{ background: 'linear-gradient(135deg, rgba(0,94,255,0.2) 0%, rgba(162,0,255,0.2) 100%)' }}
        >
          <div className="flex items-center gap-3">
            <div 
              className="h-10 w-10 rounded-full flex items-center justify-center"
              style={{ background: 'linear-gradient(135deg, #005EFF 0%, #A200FF 100%)' }}
            >
              <Bot className="h-5 w-5 text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-white">Asistente de Inventario</h3>
              <p className="text-xs text-slate-400">Powered by AI</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="h-8 w-8 rounded-full flex items-center justify-center hover:bg-white/10 transition-colors"
          >
            <X className="h-4 w-4 text-slate-400" />
          </button>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 h-[calc(100%-8rem)]">
          {messages.map((message) => (
            <div
              key={message.id}
              className={cn(
                'flex',
                message.role === 'user' ? 'justify-end' : 'justify-start'
              )}
            >
              <div
                className={cn(
                  'max-w-[85%] px-4 py-3 rounded-2xl text-sm',
                  message.role === 'user'
                    ? 'rounded-br-md text-white'
                    : 'bg-white/10 text-slate-200 rounded-bl-md'
                )}
                style={message.role === 'user' ? {
                  background: 'linear-gradient(135deg, #005EFF 0%, #2200FF 100%)'
                } : undefined}
              >
                {message.content}
              </div>
            </div>
          ))}
        </div>

        {/* Input */}
        <div className="p-4 border-t border-white/10">
          <form
            onSubmit={(e) => {
              e.preventDefault()
              handleSend()
            }}
            className="flex gap-2"
          >
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Pregunta sobre tu inventario..."
              className="flex-1 h-11 px-4 rounded-xl bg-white/10 border border-white/10 text-white placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-[#005EFF]/50 focus:border-transparent"
            />
            <button
              type="submit"
              disabled={!input.trim()}
              className="h-11 w-11 rounded-xl flex items-center justify-center text-white disabled:opacity-50 transition-all hover:scale-105 active:scale-95"
              style={{ background: 'linear-gradient(135deg, #005EFF 0%, #A200FF 100%)' }}
            >
              <Send className="h-4 w-4" />
            </button>
          </form>
        </div>
      </div>
    </>
  )
}

export function InventoryAIButton({ onClick }: { onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="fixed bottom-4 right-4 md:bottom-6 md:right-6 z-30 h-14 px-5 rounded-full shadow-lg flex items-center gap-2 transition-all hover:scale-105 hover:shadow-2xl active:scale-95 group"
      style={{ 
        background: 'linear-gradient(135deg, #005EFF 0%, #2200FF 50%, #A200FF 100%)',
        boxShadow: '0 10px 40px rgba(0,94,255,0.4)'
      }}
    >
      <Sparkles className="h-5 w-5 text-white group-hover:animate-pulse" />
      <span className="text-white font-medium text-sm">Consultar a la IA</span>
      <span className="absolute -top-1 -right-1 h-3 w-3 rounded-full bg-[#A200FF] animate-ping" />
      <span className="absolute -top-1 -right-1 h-3 w-3 rounded-full bg-[#A200FF]" />
    </button>
  )
}
