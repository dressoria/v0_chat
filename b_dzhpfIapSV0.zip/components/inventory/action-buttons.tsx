'use client'

import { FileText, Package, AlertTriangle } from 'lucide-react'
import { cn } from '@/lib/utils'

interface ActionButtonProps {
  icon: React.ReactNode
  title: string
  description: string
  gradient: string
  onClick?: () => void
}

function ActionButton({ icon, title, description, gradient, onClick }: ActionButtonProps) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "relative overflow-hidden rounded-2xl p-6 text-left transition-all",
        "hover:scale-[1.02] hover:shadow-2xl active:scale-[0.98]",
        "border border-white/10 backdrop-blur-xl",
        "group"
      )}
      style={{
        background: `linear-gradient(135deg, ${gradient})`
      }}
    >
      {/* Shine effect */}
      <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity">
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000" />
      </div>
      
      <div className="relative space-y-3">
        <div className="h-12 w-12 rounded-xl bg-white/20 flex items-center justify-center text-white">
          {icon}
        </div>
        <div>
          <h3 className="font-semibold text-white text-lg">{title}</h3>
          <p className="text-sm text-white/70 mt-1">{description}</p>
        </div>
      </div>
    </button>
  )
}

export function ActionButtons() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <ActionButton
        icon={<FileText className="h-6 w-6" />}
        title="Ingreso con Factura"
        description="Sube XML del SRI o ingresa datos manualmente"
        gradient="#005EFF 0%, #2200FF 100%"
      />
      <ActionButton
        icon={<Package className="h-6 w-6" />}
        title="Ingreso sin Factura"
        description="Remisión o ingreso directo sin comprobante"
        gradient="#2200FF 0%, #A200FF 100%"
      />
      <ActionButton
        icon={<AlertTriangle className="h-6 w-6" />}
        title="Ajuste / Merma"
        description="Registra pérdidas o ajustes de inventario"
        gradient="#A200FF 0%, #005EFF 100%"
      />
    </div>
  )
}
