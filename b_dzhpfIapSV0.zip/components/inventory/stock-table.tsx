'use client'

import { inventoryProducts } from '@/lib/inventory-data'
import { cn } from '@/lib/utils'

export function StockTable() {
  return (
    <div className="overflow-x-auto">
      <table className="w-full">
        <thead>
          <tr className="border-b border-white/10">
            <th className="text-left py-4 px-4 text-sm font-medium text-slate-400">Producto</th>
            <th className="text-left py-4 px-4 text-sm font-medium text-slate-400 hidden sm:table-cell">SKU</th>
            <th className="text-left py-4 px-4 text-sm font-medium text-slate-400 hidden md:table-cell">Categoría</th>
            <th className="text-right py-4 px-4 text-sm font-medium text-slate-400">Costo Prom.</th>
            <th className="text-right py-4 px-4 text-sm font-medium text-slate-400">Cantidad</th>
          </tr>
        </thead>
        <tbody>
          {inventoryProducts.map((product) => {
            const isLowStock = product.quantity <= product.minStock
            return (
              <tr 
                key={product.id} 
                className="border-b border-white/5 hover:bg-white/5 transition-colors"
              >
                <td className="py-4 px-4">
                  <div className="flex items-center gap-3">
                    <div className={cn(
                      "h-2 w-2 rounded-full",
                      isLowStock ? "bg-amber-500" : "bg-emerald-500"
                    )} />
                    <span className="text-white font-medium">{product.name}</span>
                  </div>
                </td>
                <td className="py-4 px-4 text-slate-400 font-mono text-sm hidden sm:table-cell">
                  {product.sku}
                </td>
                <td className="py-4 px-4 hidden md:table-cell">
                  <span className="px-2.5 py-1 rounded-lg bg-white/10 text-slate-300 text-xs">
                    {product.category}
                  </span>
                </td>
                <td className="py-4 px-4 text-right text-slate-300">
                  ${product.averageCost.toFixed(2)}
                </td>
                <td className="py-4 px-4 text-right">
                  <span className={cn(
                    "font-semibold",
                    isLowStock ? "text-amber-400" : "text-white"
                  )}>
                    {product.quantity}
                  </span>
                </td>
              </tr>
            )
          })}
        </tbody>
      </table>
    </div>
  )
}
