'use client'

import { cn } from '@/lib/utils'
import { LucideIcon } from 'lucide-react'

interface MetricCardProps {
  title: string
  value: string | number
  icon: LucideIcon
  trend?: 'up' | 'down' | 'neutral'
  trendValue?: string
  variant?: 'default' | 'warning' | 'success'
}

export function MetricCard({ 
  title, 
  value, 
  icon: Icon, 
  variant = 'default' 
}: MetricCardProps) {
  return (
    <div className="relative overflow-hidden rounded-2xl bg-white/5 backdrop-blur-xl border border-white/10 p-5 transition-all hover:bg-white/8 hover:border-white/20 group">
      {/* Gradient glow effect */}
      <div className={cn(
        "absolute -top-12 -right-12 w-32 h-32 rounded-full blur-3xl opacity-20 transition-opacity group-hover:opacity-30",
        variant === 'warning' && "bg-amber-500",
        variant === 'success' && "bg-emerald-500",
        variant === 'default' && "bg-[#005EFF]"
      )} />
      
      <div className="relative flex items-start justify-between">
        <div className="space-y-2">
          <p className="text-sm font-medium text-slate-400">{title}</p>
          <p className="text-3xl font-bold text-white">{value}</p>
        </div>
        <div className={cn(
          "h-12 w-12 rounded-xl flex items-center justify-center",
          variant === 'warning' && "bg-amber-500/20 text-amber-400",
          variant === 'success' && "bg-emerald-500/20 text-emerald-400",
          variant === 'default' && "bg-[#005EFF]/20 text-[#005EFF]"
        )}>
          <Icon className="h-6 w-6" />
        </div>
      </div>
    </div>
  )
}
