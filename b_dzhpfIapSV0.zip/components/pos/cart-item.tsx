'use client'

import Image from 'next/image'
import { Minus, Plus, Trash2 } from 'lucide-react'
import { CartItem as CartItemType } from '@/lib/pos-types'

interface CartItemProps {
  item: CartItemType
  onIncrement: (id: string) => void
  onDecrement: (id: string) => void
  onRemove: (id: string) => void
}

export function CartItem({ item, onIncrement, onDecrement, onRemove }: CartItemProps) {
  return (
    <div className="flex items-center gap-3 p-3 bg-slate-800/50 rounded-lg border border-white/5">
      <div className="relative h-14 w-14 flex-shrink-0 overflow-hidden rounded-lg bg-slate-700/50">
        <Image
          src={item.image}
          alt={item.name}
          fill
          className="object-cover"
          sizes="56px"
        />
      </div>
      
      <div className="flex-1 min-w-0">
        <h4 className="font-medium text-sm text-white truncate">
          {item.name}
        </h4>
        <p className="text-sm text-[#005EFF] font-semibold">
          ${item.price.toFixed(2)}
        </p>
      </div>
      
      <div className="flex items-center gap-1">
        <button
          className="h-8 w-8 rounded-lg bg-slate-700/50 border border-white/10 flex items-center justify-center hover:bg-slate-700 hover:border-white/20 transition-colors text-gray-300"
          onClick={() => item.quantity > 1 ? onDecrement(item.id) : onRemove(item.id)}
        >
          {item.quantity > 1 ? (
            <Minus className="h-4 w-4" />
          ) : (
            <Trash2 className="h-4 w-4 text-red-400" />
          )}
        </button>
        
        <span className="w-8 text-center font-semibold text-white">
          {item.quantity}
        </span>
        
        <button
          className="h-8 w-8 rounded-lg bg-slate-700/50 border border-white/10 flex items-center justify-center hover:bg-slate-700 hover:border-white/20 transition-colors text-gray-300 disabled:opacity-50 disabled:cursor-not-allowed"
          onClick={() => onIncrement(item.id)}
          disabled={item.quantity >= item.stock}
        >
          <Plus className="h-4 w-4" />
        </button>
      </div>
    </div>
  )
}
