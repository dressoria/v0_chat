'use client'

import { ShoppingCart } from 'lucide-react'
import { CartItem as CartItemType, InvoiceType } from '@/lib/pos-types'
import { Cart } from './cart'
import { cn } from '@/lib/utils'

interface MobileCartSheetProps {
  isOpen: boolean
  onClose: () => void
  items: CartItemType[]
  invoiceType: InvoiceType
  onInvoiceTypeChange: (type: InvoiceType) => void
  onIncrement: (id: string) => void
  onDecrement: (id: string) => void
  onRemove: (id: string) => void
  onCheckout: () => void
}

export function MobileCartSheet({
  isOpen,
  onClose,
  items,
  invoiceType,
  onInvoiceTypeChange,
  onIncrement,
  onDecrement,
  onRemove,
  onCheckout
}: MobileCartSheetProps) {
  const itemCount = items.reduce((acc, item) => acc + item.quantity, 0)

  return (
    <>
      {/* Mobile Cart Button */}
      <button
        onClick={onClose}
        className="lg:hidden fixed bottom-20 left-4 z-30 h-14 px-4 rounded-full bg-slate-900/90 backdrop-blur-xl border border-white/10 shadow-lg shadow-[#005EFF]/20 flex items-center gap-2 transition-all hover:shadow-xl hover:border-[#005EFF]/30 active:scale-95"
      >
        <ShoppingCart className="h-5 w-5 text-[#005EFF]" />
        <span className="font-semibold text-white">${items.reduce((acc, item) => acc + item.price * item.quantity, 0).toFixed(2)}</span>
        {itemCount > 0 && (
          <span className="bg-gradient-to-r from-[#005EFF] to-[#2200FF] text-white text-xs font-bold h-6 w-6 rounded-full flex items-center justify-center">
            {itemCount}
          </span>
        )}
      </button>

      {/* Overlay */}
      <div
        className={cn(
          'lg:hidden fixed inset-0 bg-slate-950/60 backdrop-blur-sm z-40 transition-opacity duration-300',
          isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
        )}
        onClick={onClose}
      />

      {/* Sheet */}
      <div
        className={cn(
          'lg:hidden fixed inset-x-0 bottom-0 z-50 h-[85vh] transition-transform duration-300 ease-out',
          isOpen ? 'translate-y-0' : 'translate-y-full'
        )}
      >
        {/* Handle */}
        <div className="flex justify-center py-2 bg-slate-900 rounded-t-2xl border-t border-x border-white/10">
          <button
            onClick={onClose}
            className="w-12 h-1.5 rounded-full bg-white/20"
          />
        </div>
        
        <div className="h-full bg-slate-900">
          <Cart
            items={items}
            invoiceType={invoiceType}
            onInvoiceTypeChange={onInvoiceTypeChange}
            onIncrement={onIncrement}
            onDecrement={onDecrement}
            onRemove={onRemove}
            onCheckout={() => {
              onCheckout()
              onClose()
            }}
          />
        </div>
      </div>
    </>
  )
}
