'use client'

import { useState } from 'react'
import { 
  ShoppingCart, 
  Receipt, 
  FileText, 
  CreditCard,
  Search,
  User,
  MapPin,
  Truck,
  Store as StoreIcon,
  Banknote,
  ArrowLeftRight,
  Plus
} from 'lucide-react'
import { CartItem as CartItemType, InvoiceType } from '@/lib/pos-types'
import { CartItem } from './cart-item'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

interface CartProps {
  items: CartItemType[]
  invoiceType: InvoiceType
  onInvoiceTypeChange: (type: InvoiceType) => void
  onIncrement: (id: string) => void
  onDecrement: (id: string) => void
  onRemove: (id: string) => void
  onCheckout: () => void
}

type DeliveryType = 'pickup' | 'delivery'
type PaymentMethod = 'cash' | 'transfer' | 'card'

const TAX_RATE = 0.15

export function Cart({
  items,
  invoiceType,
  onInvoiceTypeChange,
  onIncrement,
  onDecrement,
  onRemove,
  onCheckout
}: CartProps) {
  const [clientSearch, setClientSearch] = useState('')
  const [selectedClient, setSelectedClient] = useState<{ name: string; id: string } | null>(null)
  const [deliveryType, setDeliveryType] = useState<DeliveryType>('pickup')
  const [shippingCost, setShippingCost] = useState(0)
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('cash')

  const subtotal = items.reduce((acc, item) => acc + item.price * item.quantity, 0)
  const tax = subtotal * TAX_RATE
  const deliveryCost = deliveryType === 'delivery' ? shippingCost : 0
  const total = subtotal + tax + deliveryCost
  const itemCount = items.reduce((acc, item) => acc + item.quantity, 0)

  const handleClientSearch = () => {
    if (clientSearch.length >= 10) {
      setSelectedClient({ name: 'Juan Pérez García', id: clientSearch })
    }
  }

  return (
    <div className="flex flex-col h-full bg-slate-900/80 backdrop-blur-xl rounded-xl lg:rounded-2xl border border-white/10 overflow-hidden">
      {/* Header */}
      <div className="flex items-center gap-3 p-4 border-b border-white/10 bg-slate-800/50">
        <ShoppingCart className="h-5 w-5 text-[#005EFF]" />
        <h2 className="font-semibold text-white">Carrito</h2>
        {itemCount > 0 && (
          <span className="ml-auto bg-gradient-to-r from-[#005EFF] to-[#2200FF] text-white text-xs font-bold px-2 py-1 rounded-full">
            {itemCount}
          </span>
        )}
      </div>

      {/* Client Search */}
      <div className="p-3 border-b border-white/10 bg-slate-800/30">
        <p className="text-xs font-medium text-gray-400 mb-2 flex items-center gap-2">
          <User className="h-3.5 w-3.5" />
          Cliente (Cedula/RUC)
        </p>
        {selectedClient ? (
          <div className="flex items-center justify-between p-2.5 rounded-lg bg-[#005EFF]/10 border border-[#005EFF]/30">
            <div>
              <p className="text-sm font-medium text-white">{selectedClient.name}</p>
              <p className="text-xs text-gray-400">{selectedClient.id}</p>
            </div>
            <button 
              onClick={() => { setSelectedClient(null); setClientSearch(''); }}
              className="text-xs text-[#005EFF] hover:underline"
            >
              Cambiar
            </button>
          </div>
        ) : (
          <div className="flex gap-2">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-500" />
              <input
                type="text"
                value={clientSearch}
                onChange={(e) => setClientSearch(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleClientSearch()}
                placeholder="Buscar o crear cliente..."
                className="w-full pl-9 pr-3 py-2 bg-slate-800/50 border border-white/10 rounded-lg text-sm text-white placeholder:text-gray-500 focus:outline-none focus:ring-2 focus:ring-[#005EFF]/50 focus:border-[#005EFF]/50"
              />
            </div>
            <Button
              size="icon"
              className="bg-gradient-to-r from-[#005EFF] to-[#2200FF] hover:opacity-90 border-0"
              onClick={handleClientSearch}
            >
              <Plus className="h-4 w-4" />
            </Button>
          </div>
        )}
      </div>

      {/* Items */}
      <div className="flex-1 overflow-y-auto p-3 space-y-2">
        {items.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-gray-500 py-8">
            <ShoppingCart className="h-12 w-12 mb-3 opacity-30" />
            <p className="text-sm font-medium text-gray-400">Carrito vacio</p>
            <p className="text-xs text-gray-500">Selecciona productos para agregar</p>
          </div>
        ) : (
          items.map((item) => (
            <CartItem
              key={item.id}
              item={item}
              onIncrement={onIncrement}
              onDecrement={onDecrement}
              onRemove={onRemove}
            />
          ))
        )}
      </div>

      {/* Delivery Type */}
      <div className="p-3 border-t border-white/10 bg-slate-800/30">
        <p className="text-xs font-medium text-gray-400 mb-2 flex items-center gap-2">
          <MapPin className="h-3.5 w-3.5" />
          Tipo de Entrega
        </p>
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={() => setDeliveryType('pickup')}
            className={cn(
              'flex items-center justify-center gap-2 p-2.5 rounded-lg border transition-all text-sm font-medium',
              deliveryType === 'pickup'
                ? 'border-[#005EFF] bg-[#005EFF]/10 text-[#005EFF]'
                : 'border-white/10 hover:border-[#005EFF]/50 text-gray-400'
            )}
          >
            <StoreIcon className="h-4 w-4" />
            Retiro en Tienda
          </button>
          <button
            onClick={() => setDeliveryType('delivery')}
            className={cn(
              'flex items-center justify-center gap-2 p-2.5 rounded-lg border transition-all text-sm font-medium',
              deliveryType === 'delivery'
                ? 'border-[#A200FF] bg-[#A200FF]/10 text-[#A200FF]'
                : 'border-white/10 hover:border-[#A200FF]/50 text-gray-400'
            )}
          >
            <Truck className="h-4 w-4" />
            Envio
          </button>
        </div>
        {deliveryType === 'delivery' && (
          <div className="mt-2">
            <label className="text-xs text-gray-500">Costo de envio ($)</label>
            <input
              type="number"
              min="0"
              step="0.50"
              value={shippingCost}
              onChange={(e) => setShippingCost(parseFloat(e.target.value) || 0)}
              className="w-full mt-1 px-3 py-2 bg-slate-800/50 border border-white/10 rounded-lg text-sm text-white focus:outline-none focus:ring-2 focus:ring-[#A200FF]/50"
            />
          </div>
        )}
      </div>

      {/* Payment Method */}
      <div className="p-3 border-t border-white/10 bg-slate-800/30">
        <p className="text-xs font-medium text-gray-400 mb-2 flex items-center gap-2">
          <CreditCard className="h-3.5 w-3.5" />
          Metodo de Pago
        </p>
        <div className="grid grid-cols-3 gap-2">
          <button
            onClick={() => setPaymentMethod('cash')}
            className={cn(
              'flex flex-col items-center gap-1 p-2.5 rounded-lg border transition-all',
              paymentMethod === 'cash'
                ? 'border-[#005EFF] bg-[#005EFF]/10 text-[#005EFF]'
                : 'border-white/10 hover:border-[#005EFF]/50 text-gray-400'
            )}
          >
            <Banknote className="h-4 w-4" />
            <span className="text-[10px] font-medium">Efectivo</span>
          </button>
          <button
            onClick={() => setPaymentMethod('transfer')}
            className={cn(
              'flex flex-col items-center gap-1 p-2.5 rounded-lg border transition-all',
              paymentMethod === 'transfer'
                ? 'border-[#2200FF] bg-[#2200FF]/10 text-[#2200FF]'
                : 'border-white/10 hover:border-[#2200FF]/50 text-gray-400'
            )}
          >
            <ArrowLeftRight className="h-4 w-4" />
            <span className="text-[10px] font-medium">Transferencia</span>
          </button>
          <button
            onClick={() => setPaymentMethod('card')}
            className={cn(
              'flex flex-col items-center gap-1 p-2.5 rounded-lg border transition-all',
              paymentMethod === 'card'
                ? 'border-[#A200FF] bg-[#A200FF]/10 text-[#A200FF]'
                : 'border-white/10 hover:border-[#A200FF]/50 text-gray-400'
            )}
          >
            <CreditCard className="h-4 w-4" />
            <span className="text-[10px] font-medium">Tarjeta</span>
          </button>
        </div>
      </div>

      {/* Invoice Type Selector */}
      <div className="p-3 border-t border-white/10 bg-slate-800/30">
        <p className="text-xs font-medium text-gray-400 mb-2">Tipo de comprobante</p>
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={() => onInvoiceTypeChange('nota-venta')}
            className={cn(
              'flex items-center gap-2 p-2.5 rounded-lg border transition-all text-left',
              invoiceType === 'nota-venta'
                ? 'border-[#005EFF] bg-[#005EFF]/10 text-[#005EFF]'
                : 'border-white/10 hover:border-[#005EFF]/50 text-gray-300'
            )}
          >
            <Receipt className="h-4 w-4 flex-shrink-0" />
            <div>
              <p className="text-xs font-semibold">Nota de Venta</p>
              <p className="text-[10px] opacity-70">Interna</p>
            </div>
          </button>
          <button
            onClick={() => onInvoiceTypeChange('factura-sri')}
            className={cn(
              'flex items-center gap-2 p-2.5 rounded-lg border transition-all text-left',
              invoiceType === 'factura-sri'
                ? 'border-[#A200FF] bg-[#A200FF]/10 text-[#A200FF]'
                : 'border-white/10 hover:border-[#A200FF]/50 text-gray-300'
            )}
          >
            <FileText className="h-4 w-4 flex-shrink-0" />
            <div>
              <p className="text-xs font-semibold">Factura SRI</p>
              <p className="text-[10px] opacity-70">Electronica</p>
            </div>
          </button>
        </div>
      </div>

      {/* Totals */}
      <div className="p-4 border-t border-white/10 bg-slate-800/30 space-y-2">
        <div className="flex justify-between text-sm text-gray-400">
          <span>Subtotal</span>
          <span>${subtotal.toFixed(2)}</span>
        </div>
        <div className="flex justify-between text-sm text-gray-400">
          <span>IVA (15%)</span>
          <span>${tax.toFixed(2)}</span>
        </div>
        {deliveryType === 'delivery' && deliveryCost > 0 && (
          <div className="flex justify-between text-sm text-gray-400">
            <span>Envio</span>
            <span>${deliveryCost.toFixed(2)}</span>
          </div>
        )}
        <div className="flex justify-between text-lg font-bold text-white pt-2 border-t border-white/10">
          <span>Total</span>
          <span className="text-[#005EFF]">${total.toFixed(2)}</span>
        </div>
      </div>

      {/* Checkout Button */}
      <div className="p-4 bg-slate-800/30">
        <Button
          onClick={onCheckout}
          disabled={items.length === 0}
          className="w-full h-14 text-lg font-bold bg-gradient-to-r from-[#005EFF] to-[#2200FF] hover:from-[#005EFF]/90 hover:to-[#2200FF]/90 text-white rounded-xl shadow-lg shadow-[#005EFF]/25 transition-all hover:shadow-xl hover:shadow-[#005EFF]/30 disabled:opacity-50 disabled:shadow-none border-0"
        >
          <CreditCard className="h-5 w-5 mr-2" />
          Cobrar ${total.toFixed(2)}
        </Button>
      </div>
    </div>
  )
}
