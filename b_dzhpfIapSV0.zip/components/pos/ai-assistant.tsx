'use client'

import { useState } from 'react'
import { X, Send, Sparkles, Bot } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

interface Message {
  id: string
  role: 'user' | 'assistant'
  content: string
}

interface AIAssistantProps {
  isOpen: boolean
  onClose: () => void
}

export function AIAssistant({ isOpen, onClose }: AIAssistantProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content: '¡Hola! Soy tu asistente de negocio con IA. Puedo ayudarte a consultar información sobre tu inventario, ventas, productos más vendidos, y mucho más. ¿Qué necesitas saber?'
    }
  ])
  const [input, setInput] = useState('')

  const handleSend = () => {
    if (!input.trim()) return

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input
    }

    setMessages((prev) => [...prev, userMessage])
    setInput('')

    // Simulate AI response
    setTimeout(() => {
      const responses = [
        'Según tus datos de ventas, la Proteína Whey 2kg es tu producto más vendido este mes con 45 unidades.',
        'Tu inventario actual tiene 12 productos, con un valor total de $2,847.50. Hay 3 productos con stock bajo.',
        'Las ventas de hoy suman $523.45 con 8 transacciones. El promedio por venta es de $65.43.',
        'Te recomiendo revisar el stock de Crema Anti-edad, solo quedan 15 unidades y tiene alta rotación.',
        'El margen de ganancia promedio de tus productos de cuidado de piel es del 42%, el más alto de todas las categorías.'
      ]
      
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: responses[Math.floor(Math.random() * responses.length)]
      }
      
      setMessages((prev) => [...prev, assistantMessage])
    }, 1000)
  }

  return (
    <>
      {/* Overlay */}
      <div
        className={cn(
          'fixed inset-0 bg-slate-950/60 backdrop-blur-sm z-40 transition-opacity duration-300',
          isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
        )}
        onClick={onClose}
      />

      {/* Chat Window */}
      <div
        className={cn(
          'fixed z-50 bg-slate-900/95 backdrop-blur-xl border border-white/10 rounded-2xl shadow-2xl shadow-[#005EFF]/10 transition-all duration-300 ease-out',
          'bottom-24 right-4 w-[calc(100%-2rem)] max-w-md h-[70vh] max-h-[500px]',
          'md:bottom-24 md:right-6 md:w-96',
          isOpen ? 'translate-y-0 opacity-100' : 'translate-y-8 opacity-0 pointer-events-none'
        )}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-white/10 bg-gradient-to-r from-[#005EFF]/10 to-[#A200FF]/10 rounded-t-2xl">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-full bg-gradient-to-br from-[#005EFF] to-[#A200FF] flex items-center justify-center shadow-lg shadow-[#005EFF]/30">
              <Bot className="h-5 w-5 text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-white">Asistente de Negocio</h3>
              <p className="text-xs text-gray-400">Consulta inventario y ventas</p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="h-8 w-8 rounded-full hover:bg-white/10 text-gray-400 hover:text-white"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 h-[calc(100%-8rem)]">
          {messages.map((message) => (
            <div
              key={message.id}
              className={cn(
                'flex',
                message.role === 'user' ? 'justify-end' : 'justify-start'
              )}
            >
              <div
                className={cn(
                  'max-w-[85%] px-4 py-3 rounded-2xl text-sm',
                  message.role === 'user'
                    ? 'bg-gradient-to-r from-[#005EFF] to-[#2200FF] text-white rounded-br-md'
                    : 'bg-slate-800/80 text-gray-200 rounded-bl-md border border-white/5'
                )}
              >
                {message.content}
              </div>
            </div>
          ))}
        </div>

        {/* Input */}
        <div className="p-4 border-t border-white/10">
          <form
            onSubmit={(e) => {
              e.preventDefault()
              handleSend()
            }}
            className="flex gap-2"
          >
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Pregunta sobre tu negocio..."
              className="flex-1 h-11 px-4 rounded-xl bg-slate-800/50 border border-white/10 text-white placeholder:text-gray-500 focus:outline-none focus:border-[#005EFF]/50 focus:ring-2 focus:ring-[#005EFF]/20 transition-all"
            />
            <Button
              type="submit"
              size="icon"
              disabled={!input.trim()}
              className="h-11 w-11 rounded-xl bg-gradient-to-r from-[#005EFF] to-[#2200FF] hover:from-[#005EFF]/90 hover:to-[#2200FF]/90 border-0 shadow-lg shadow-[#005EFF]/25"
            >
              <Send className="h-4 w-4" />
            </Button>
          </form>
        </div>
      </div>
    </>
  )
}

export function AIAssistantButton({ onClick }: { onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="fixed bottom-4 right-4 md:bottom-6 md:right-6 z-30 h-14 w-14 rounded-full bg-gradient-to-br from-[#005EFF] via-[#2200FF] to-[#A200FF] shadow-lg shadow-[#005EFF]/40 flex items-center justify-center transition-all hover:scale-110 hover:shadow-xl hover:shadow-[#005EFF]/50 active:scale-95 group"
    >
      <Sparkles className="h-6 w-6 text-white group-hover:animate-pulse" />
      <span className="absolute -top-1 -right-1 h-4 w-4 rounded-full bg-[#A200FF] animate-ping" />
      <span className="absolute -top-1 -right-1 h-4 w-4 rounded-full bg-[#A200FF]" />
    </button>
  )
}
