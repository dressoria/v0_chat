'use client'

import { useState, useMemo } from 'react'
import { Product, CartItem as CartItemType, InvoiceType } from '@/lib/pos-types'
import { products as allProducts } from '@/lib/products-data'
import { SearchBar } from './search-bar'
import { ProductGrid } from './product-grid'
import { Cart } from './cart'
import { MobileCartSheet } from './mobile-cart-sheet'
import { AIAssistant, AIAssistantButton } from './ai-assistant'
import { AppLayout } from '@/components/layout/app-layout'

export function POSLayout() {
  const [search, setSearch] = useState('')
  const [cart, setCart] = useState<CartItemType[]>([])
  const [invoiceType, setInvoiceType] = useState<InvoiceType>('nota-venta')
  const [isCartOpen, setIsCartOpen] = useState(false)
  const [isAIOpen, setIsAIOpen] = useState(false)

  const filteredProducts = useMemo(() => {
    if (!search.trim()) return allProducts
    const query = search.toLowerCase()
    return allProducts.filter(
      (p) =>
        p.name.toLowerCase().includes(query) ||
        p.category.toLowerCase().includes(query)
    )
  }, [search])

  const addToCart = (product: Product) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.id === product.id)
      if (existing) {
        if (existing.quantity >= product.stock) return prev
        return prev.map((item) =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        )
      }
      return [...prev, { ...product, quantity: 1 }]
    })
  }

  const incrementItem = (id: string) => {
    setCart((prev) =>
      prev.map((item) => {
        if (item.id === id && item.quantity < item.stock) {
          return { ...item, quantity: item.quantity + 1 }
        }
        return item
      })
    )
  }

  const decrementItem = (id: string) => {
    setCart((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, quantity: Math.max(1, item.quantity - 1) } : item
      )
    )
  }

  const removeItem = (id: string) => {
    setCart((prev) => prev.filter((item) => item.id !== id))
  }

  const handleCheckout = () => {
    if (cart.length === 0) return
    
    const total = cart.reduce((acc, item) => acc + item.price * item.quantity, 0)
    const tax = total * 0.15
    const finalTotal = total + tax
    
    alert(
      `Venta procesada exitosamente\n\n` +
      `Tipo: ${invoiceType === 'nota-venta' ? 'Nota de Venta Interna' : 'Factura Electronica SRI'}\n` +
      `Total: $${finalTotal.toFixed(2)}\n\n` +
      `Gracias por su compra!`
    )
    
    setCart([])
  }

  return (
    <AppLayout title="Punto de Venta" subtitle="Registrar ventas y cobros">
      <div className="flex max-w-screen-2xl mx-auto">
        {/* Main Content */}
        <div className="flex-1 p-4 md:p-6 pb-32 lg:pb-6">
          {/* Search */}
          <div className="mb-6">
            <SearchBar value={search} onChange={setSearch} />
          </div>

          {/* Category Pills */}
          <div className="flex gap-2 mb-6 overflow-x-auto pb-2 -mx-4 px-4 md:mx-0 md:px-0 scrollbar-hide">
            {['Todos', 'Vitaminas', 'Suplementos', 'Cuidado Piel'].map((category) => (
              <button
                key={category}
                onClick={() => setSearch(category === 'Todos' ? '' : category)}
                className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all ${
                  (category === 'Todos' && !search) ||
                  search.toLowerCase() === category.toLowerCase().replace(' ', '-')
                    ? 'bg-gradient-to-r from-[#005EFF] to-[#2200FF] text-white shadow-lg shadow-[#005EFF]/25'
                    : 'bg-slate-800/50 border border-white/10 text-gray-300 hover:border-[#005EFF]/50 hover:text-white'
                }`}
              >
                {category}
              </button>
            ))}
          </div>

          {/* Products Grid */}
          <ProductGrid products={filteredProducts} onAddToCart={addToCart} />
        </div>

        {/* Desktop Cart */}
        <aside className="hidden lg:block w-[420px] p-4 pl-0">
          <div className="sticky top-20">
            <Cart
              items={cart}
              invoiceType={invoiceType}
              onInvoiceTypeChange={setInvoiceType}
              onIncrement={incrementItem}
              onDecrement={decrementItem}
              onRemove={removeItem}
              onCheckout={handleCheckout}
            />
          </div>
        </aside>
      </div>

      {/* Mobile Cart */}
      <MobileCartSheet
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(!isCartOpen)}
        items={cart}
        invoiceType={invoiceType}
        onInvoiceTypeChange={setInvoiceType}
        onIncrement={incrementItem}
        onDecrement={decrementItem}
        onRemove={removeItem}
        onCheckout={handleCheckout}
      />

      {/* AI Assistant */}
      <AIAssistantButton onClick={() => setIsAIOpen(true)} />
      <AIAssistant isOpen={isAIOpen} onClose={() => setIsAIOpen(false)} />
    </AppLayout>
  )
}
