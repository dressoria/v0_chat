'use client'

import { Search, X } from 'lucide-react'

interface SearchBarProps {
  value: string
  onChange: (value: string) => void
}

export function SearchBar({ value, onChange }: SearchBarProps) {
  return (
    <div className="relative w-full">
      <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
      <input
        type="text"
        placeholder="Buscar productos por nombre o categoría..."
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full h-12 md:h-14 pl-12 pr-12 text-base md:text-lg bg-slate-800/50 backdrop-blur-sm border border-white/10 rounded-xl text-white placeholder:text-gray-500 focus:outline-none focus:border-[#005EFF]/50 focus:ring-2 focus:ring-[#005EFF]/20 transition-all"
      />
      {value && (
        <button
          onClick={() => onChange('')}
          className="absolute right-4 top-1/2 -translate-y-1/2 h-6 w-6 rounded-full bg-slate-700 flex items-center justify-center hover:bg-slate-600 transition-colors"
        >
          <X className="h-4 w-4 text-gray-300" />
        </button>
      )}
    </div>
  )
}
