'use client'

import Image from 'next/image'
import { Product } from '@/lib/pos-types'
import { cn } from '@/lib/utils'

interface ProductCardProps {
  product: Product
  onAdd: (product: Product) => void
  priority?: boolean
}

export function ProductCard({ product, onAdd, priority = false }: ProductCardProps) {
  const isLowStock = product.stock <= 10

  return (
    <button
      onClick={() => onAdd(product)}
      disabled={product.stock === 0}
      className={cn(
        'group relative flex flex-col overflow-hidden rounded-xl bg-slate-800/50 backdrop-blur-sm border border-white/10 p-3 text-left transition-all duration-200',
        'hover:shadow-lg hover:shadow-[#005EFF]/10 hover:border-[#005EFF]/30 hover:scale-[1.02]',
        'active:scale-[0.98]',
        'disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100'
      )}
    >
      <div className="relative aspect-square w-full overflow-hidden rounded-lg bg-slate-700/50 mb-3">
        <Image
          src={product.image}
          alt={product.name}
          fill
          priority={priority}
          loading={priority ? "eager" : "lazy"}
          className="object-cover transition-transform duration-300 group-hover:scale-105"
          sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 20vw"
        />
        {isLowStock && product.stock > 0 && (
          <span className="absolute top-2 right-2 bg-amber-500 text-amber-950 text-xs font-medium px-2 py-0.5 rounded-full">
            Poco stock
          </span>
        )}
        {product.stock === 0 && (
          <div className="absolute inset-0 bg-slate-900/80 flex items-center justify-center">
            <span className="bg-red-500/20 text-red-400 border border-red-500/30 text-sm font-medium px-3 py-1 rounded-full">
              Agotado
            </span>
          </div>
        )}
      </div>
      
      <h3 className="font-medium text-sm text-white line-clamp-2 leading-tight mb-1">
        {product.name}
      </h3>
      
      <div className="mt-auto flex items-end justify-between">
        <span className="text-lg font-bold text-[#005EFF]">
          ${product.price.toFixed(2)}
        </span>
        <span className="text-xs text-gray-400">
          Stock: {product.stock}
        </span>
      </div>
    </button>
  )
}
