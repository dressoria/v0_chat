'use client'

import { Bell, Settings, Menu } from 'lucide-react'
import { Button } from '@/components/ui/button'

interface HeaderProps {
  title: string
  subtitle?: string
  onMenuClick: () => void
  sidebarCollapsed: boolean
}

export function Header({ title, subtitle, onMenuClick, sidebarCollapsed }: HeaderProps) {
  return (
    <header className="sticky top-0 z-30 bg-slate-950/80 backdrop-blur-xl border-b border-white/10">
      <div className="flex items-center justify-between px-4 lg:px-6 h-16">
        {/* Left Side */}
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            className="lg:hidden text-gray-400 hover:text-white hover:bg-white/10"
            onClick={onMenuClick}
          >
            <Menu className="h-5 w-5" />
          </Button>
          <div>
            <h1 className="text-lg font-bold text-white">{title}</h1>
            {subtitle && (
              <p className="text-xs text-gray-400">{subtitle}</p>
            )}
          </div>
        </div>

        {/* Right Side - Fixed 3 Buttons */}
        <div className="flex items-center gap-2">
          {/* Notifications */}
          <Button
            variant="ghost"
            size="icon"
            className="relative text-gray-400 hover:text-white hover:bg-white/10 rounded-lg"
          >
            <Bell className="h-5 w-5" />
            <span className="absolute top-1.5 right-1.5 h-2 w-2 bg-[#005EFF] rounded-full" />
          </Button>

          {/* Settings */}
          <Button
            variant="ghost"
            size="icon"
            className="text-gray-400 hover:text-white hover:bg-white/10 rounded-lg"
          >
            <Settings className="h-5 w-5" />
          </Button>

          {/* Avatar */}
          <div className="h-9 w-9 rounded-full bg-gradient-to-br from-[#005EFF] via-[#2200FF] to-[#A200FF] flex items-center justify-center cursor-pointer hover:ring-2 hover:ring-[#005EFF]/50 transition-all">
            <span className="text-sm font-semibold text-white">ML</span>
          </div>
        </div>
      </div>
    </header>
  )
}
