import { InventoryProduct, InventoryMovement } from './inventory-types'

export const inventoryProducts: InventoryProduct[] = [
  {
    id: '1',
    name: 'Proteína Whey Premium 2kg',
    sku: 'PRO-WHY-2KG',
    category: 'Suplementos',
    averageCost: 45.50,
    quantity: 24,
    minStock: 10
  },
  {
    id: '2',
    name: 'Creatina Monohidratada 500g',
    sku: 'CRE-MON-500',
    category: 'Suplementos',
    averageCost: 22.30,
    quantity: 18,
    minStock: 8
  },
  {
    id: '3',
    name: 'Vitamina D3 5000 UI x60',
    sku: 'VIT-D3-60',
    category: 'Vitaminas',
    averageCost: 8.90,
    quantity: 45,
    minStock: 20
  },
  {
    id: '4',
    name: 'Omega 3 Fish Oil x90',
    sku: 'OME-3-90',
    category: 'Vitaminas',
    averageCost: 15.20,
    quantity: 32,
    minStock: 15
  },
  {
    id: '5',
    name: 'Crema Anti-edad Retinol 50ml',
    sku: 'CRE-RET-50',
    category: 'Cuidado Piel',
    averageCost: 28.00,
    quantity: 5,
    minStock: 10
  },
  {
    id: '6',
    name: 'Sérum Vitamina C 30ml',
    sku: 'SER-VIC-30',
    category: 'Cuidado Piel',
    averageCost: 19.50,
    quantity: 8,
    minStock: 12
  },
  {
    id: '7',
    name: 'BCAA 2:1:1 Powder 400g',
    sku: 'BCA-211-400',
    category: 'Suplementos',
    averageCost: 18.75,
    quantity: 22,
    minStock: 10
  },
  {
    id: '8',
    name: 'Multivitamínico Completo x120',
    sku: 'MUL-COM-120',
    category: 'Vitaminas',
    averageCost: 12.40,
    quantity: 38,
    minStock: 15
  },
  {
    id: '9',
    name: 'Colágeno Hidrolizado 300g',
    sku: 'COL-HID-300',
    category: 'Suplementos',
    averageCost: 24.80,
    quantity: 3,
    minStock: 8
  },
  {
    id: '10',
    name: 'Protector Solar SPF 50 100ml',
    sku: 'PRO-SOL-100',
    category: 'Cuidado Piel',
    averageCost: 14.30,
    quantity: 27,
    minStock: 10
  }
]

export const inventoryMovements: InventoryMovement[] = [
  {
    id: '1',
    date: '2024-01-15 09:30',
    type: 'purchase',
    productName: 'Proteína Whey Premium 2kg',
    quantity: 12,
    user: 'Carlos M.'
  },
  {
    id: '2',
    date: '2024-01-15 10:15',
    type: 'sale',
    productName: 'Vitamina D3 5000 UI x60',
    quantity: -3,
    user: 'Sistema POS'
  },
  {
    id: '3',
    date: '2024-01-15 11:00',
    type: 'adjustment',
    productName: 'Crema Anti-edad Retinol 50ml',
    quantity: -2,
    user: 'Ana R.'
  },
  {
    id: '4',
    date: '2024-01-15 14:20',
    type: 'purchase',
    productName: 'Omega 3 Fish Oil x90',
    quantity: 20,
    user: 'Carlos M.'
  },
  {
    id: '5',
    date: '2024-01-15 15:45',
    type: 'sale',
    productName: 'Sérum Vitamina C 30ml',
    quantity: -4,
    user: 'Sistema POS'
  },
  {
    id: '6',
    date: '2024-01-15 16:30',
    type: 'loss',
    productName: 'Colágeno Hidrolizado 300g',
    quantity: -1,
    user: 'Ana R.'
  },
  {
    id: '7',
    date: '2024-01-14 10:00',
    type: 'purchase',
    productName: 'BCAA 2:1:1 Powder 400g',
    quantity: 15,
    user: 'Carlos M.'
  },
  {
    id: '8',
    date: '2024-01-14 13:30',
    type: 'sale',
    productName: 'Proteína Whey Premium 2kg',
    quantity: -5,
    user: 'Sistema POS'
  }
]

export const getMovementTypeLabel = (type: InventoryMovement['type']): string => {
  const labels: Record<InventoryMovement['type'], string> = {
    purchase: 'Compra',
    sale: 'Venta',
    adjustment: 'Ajuste',
    loss: 'Merma'
  }
  return labels[type]
}

export const getMovementTypeColor = (type: InventoryMovement['type']): string => {
  const colors: Record<InventoryMovement['type'], string> = {
    purchase: 'text-emerald-400',
    sale: 'text-cyan-400',
    adjustment: 'text-amber-400',
    loss: 'text-red-400'
  }
  return colors[type]
}
