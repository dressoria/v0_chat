export interface Product {
  id: string
  name: string
  price: number
  stock: number
  image: string
  category: string
}

export interface CartItem extends Product {
  quantity: number
}

export type InvoiceType = 'nota-venta' | 'factura-sri'
