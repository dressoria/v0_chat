export interface FinancialMetric {
  id: string
  label: string
  value: number
  change: number
  changeType: 'positive' | 'negative' | 'neutral'
  icon: string
}

export interface MonthlyData {
  month: string
  ingresos: number
  egresos: number
}

export interface Comprobante {
  id: string
  tipo: string
  numero: string
  fecha: string
  cliente: string
  monto: number
  estado: 'autorizado' | 'rechazado' | 'pendiente'
  claveAcceso: string
}

export interface CuentaContable {
  id: string
  codigo: string
  nombre: string
  tipo: 'activo' | 'pasivo' | 'patrimonio' | 'ingreso' | 'gasto'
  nivel: number
  saldo: number
  children?: CuentaContable[]
}

export interface AsientoContable {
  id: string
  fecha: string
  descripcion: string
  debe: number
  haber: number
  cuenta: string
}

export interface AIInsight {
  id: string
  message: string
  type: 'warning' | 'success' | 'info'
  action?: string
}
