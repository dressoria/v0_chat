import type { FinancialMetric, MonthlyData, Comprobante, CuentaContable, AsientoContable, AIInsight } from './finance-types'

export const financialMetrics: FinancialMetric[] = [
  {
    id: '1',
    label: 'Flujo de Caja Actual',
    value: 47850.32,
    change: 12.5,
    changeType: 'positive',
    icon: 'wallet'
  },
  {
    id: '2',
    label: 'Cuentas por Cobrar',
    value: 15420.00,
    change: 8.2,
    changeType: 'negative',
    icon: 'arrow-up'
  },
  {
    id: '3',
    label: 'Cuentas por Pagar',
    value: 8930.50,
    change: -5.3,
    changeType: 'positive',
    icon: 'arrow-down'
  },
  {
    id: '4',
    label: 'Utilidad Neta',
    value: 23540.82,
    change: 18.7,
    changeType: 'positive',
    icon: 'trending-up'
  }
]

export const monthlyData: MonthlyData[] = [
  { month: 'Ene', ingresos: 32000, egresos: 24000 },
  { month: 'Feb', ingresos: 38000, egresos: 28000 },
  { month: 'Mar', ingresos: 35000, egresos: 26000 },
  { month: 'Abr', ingresos: 42000, egresos: 31000 },
  { month: 'May', ingresos: 48000, egresos: 35000 },
  { month: 'Jun', ingresos: 52000, egresos: 38000 },
  { month: 'Jul', ingresos: 49000, egresos: 36000 },
  { month: 'Ago', ingresos: 55000, egresos: 40000 },
  { month: 'Sep', ingresos: 58000, egresos: 42000 },
  { month: 'Oct', ingresos: 62000, egresos: 45000 },
  { month: 'Nov', ingresos: 68000, egresos: 48000 },
  { month: 'Dic', ingresos: 75000, egresos: 52000 }
]

export const comprobantes: Comprobante[] = [
  {
    id: '1',
    tipo: 'Factura',
    numero: '001-001-000000145',
    fecha: '2024-01-15',
    cliente: 'Distribuidora ABC S.A.',
    monto: 2450.80,
    estado: 'autorizado',
    claveAcceso: '1501202401099012345600110010010000001450000014517'
  },
  {
    id: '2',
    tipo: 'Factura',
    numero: '001-001-000000146',
    fecha: '2024-01-15',
    cliente: 'Comercial XYZ Cia. Ltda.',
    monto: 1890.00,
    estado: 'autorizado',
    claveAcceso: '1501202401099012345600110010010000001460000018907'
  },
  {
    id: '3',
    tipo: 'Nota de Crédito',
    numero: '001-001-000000023',
    fecha: '2024-01-14',
    cliente: 'Importadora del Sur',
    monto: 350.00,
    estado: 'pendiente',
    claveAcceso: '1401202401099012345600110010010000000230000003501'
  },
  {
    id: '4',
    tipo: 'Factura',
    numero: '001-001-000000144',
    fecha: '2024-01-14',
    cliente: 'Farmacias Unidas',
    monto: 3200.50,
    estado: 'rechazado',
    claveAcceso: '1401202401099012345600110010010000001440000032005'
  },
  {
    id: '5',
    tipo: 'Retención',
    numero: '001-001-000000089',
    fecha: '2024-01-13',
    cliente: 'Supermercados Nacional',
    monto: 245.00,
    estado: 'autorizado',
    claveAcceso: '1301202401099012345600110010010000000890000002451'
  }
]

export const planCuentas: CuentaContable[] = [
  {
    id: '1',
    codigo: '1',
    nombre: 'ACTIVO',
    tipo: 'activo',
    nivel: 1,
    saldo: 125680.45,
    children: [
      {
        id: '1.1',
        codigo: '1.1',
        nombre: 'ACTIVO CORRIENTE',
        tipo: 'activo',
        nivel: 2,
        saldo: 89450.32,
        children: [
          { id: '1.1.01', codigo: '1.1.01', nombre: 'Caja', tipo: 'activo', nivel: 3, saldo: 5420.00 },
          { id: '1.1.02', codigo: '1.1.02', nombre: 'Bancos', tipo: 'activo', nivel: 3, saldo: 42430.32 },
          { id: '1.1.03', codigo: '1.1.03', nombre: 'Cuentas por Cobrar', tipo: 'activo', nivel: 3, saldo: 15420.00 },
          { id: '1.1.04', codigo: '1.1.04', nombre: 'Inventarios', tipo: 'activo', nivel: 3, saldo: 26180.00 }
        ]
      },
      {
        id: '1.2',
        codigo: '1.2',
        nombre: 'ACTIVO NO CORRIENTE',
        tipo: 'activo',
        nivel: 2,
        saldo: 36230.13,
        children: [
          { id: '1.2.01', codigo: '1.2.01', nombre: 'Propiedad, Planta y Equipo', tipo: 'activo', nivel: 3, saldo: 45000.00 },
          { id: '1.2.02', codigo: '1.2.02', nombre: 'Depreciación Acumulada', tipo: 'activo', nivel: 3, saldo: -8769.87 }
        ]
      }
    ]
  },
  {
    id: '2',
    codigo: '2',
    nombre: 'PASIVO',
    tipo: 'pasivo',
    nivel: 1,
    saldo: 45320.18,
    children: [
      {
        id: '2.1',
        codigo: '2.1',
        nombre: 'PASIVO CORRIENTE',
        tipo: 'pasivo',
        nivel: 2,
        saldo: 32450.18,
        children: [
          { id: '2.1.01', codigo: '2.1.01', nombre: 'Cuentas por Pagar', tipo: 'pasivo', nivel: 3, saldo: 8930.50 },
          { id: '2.1.02', codigo: '2.1.02', nombre: 'IVA por Pagar', tipo: 'pasivo', nivel: 3, saldo: 4520.68 },
          { id: '2.1.03', codigo: '2.1.03', nombre: 'Retenciones por Pagar', tipo: 'pasivo', nivel: 3, saldo: 1890.00 },
          { id: '2.1.04', codigo: '2.1.04', nombre: 'Obligaciones Bancarias C/P', tipo: 'pasivo', nivel: 3, saldo: 17109.00 }
        ]
      }
    ]
  },
  {
    id: '3',
    codigo: '3',
    nombre: 'PATRIMONIO',
    tipo: 'patrimonio',
    nivel: 1,
    saldo: 80360.27,
    children: [
      { id: '3.1', codigo: '3.1', nombre: 'Capital Social', tipo: 'patrimonio', nivel: 2, saldo: 50000.00 },
      { id: '3.2', codigo: '3.2', nombre: 'Reservas', tipo: 'patrimonio', nivel: 2, saldo: 6819.45 },
      { id: '3.3', codigo: '3.3', nombre: 'Resultados Acumulados', tipo: 'patrimonio', nivel: 2, saldo: 23540.82 }
    ]
  }
]

export const asientosRecientes: AsientoContable[] = [
  { id: '1', fecha: '2024-01-15', descripcion: 'Venta de mercadería según factura #145', debe: 2450.80, haber: 0, cuenta: '1.1.03 - Cuentas por Cobrar' },
  { id: '2', fecha: '2024-01-15', descripcion: 'Venta de mercadería según factura #145', debe: 0, haber: 2188.21, cuenta: '4.1.01 - Ventas' },
  { id: '3', fecha: '2024-01-15', descripcion: 'IVA en venta según factura #145', debe: 0, haber: 262.59, cuenta: '2.1.02 - IVA por Pagar' },
  { id: '4', fecha: '2024-01-14', descripcion: 'Pago a proveedor Distribuidora Norte', debe: 1500.00, haber: 0, cuenta: '2.1.01 - Cuentas por Pagar' },
  { id: '5', fecha: '2024-01-14', descripcion: 'Pago a proveedor Distribuidora Norte', debe: 0, haber: 1500.00, cuenta: '1.1.02 - Bancos' }
]

export const aiInsights: AIInsight[] = [
  {
    id: '1',
    message: 'Tus cuentas por cobrar superan los $15,000 este mes. Te sugiero enviar recordatorios automáticos de pago a 8 clientes con facturas vencidas.',
    type: 'warning',
    action: 'Enviar Recordatorios'
  },
  {
    id: '2',
    message: 'Tu flujo de caja ha mejorado un 12.5% respecto al mes anterior. Considera invertir el excedente en inventario de alta rotación.',
    type: 'success',
    action: 'Ver Análisis'
  },
  {
    id: '3',
    message: 'Detecté que el Formulario 104 de IVA vence en 5 días. Ya tienes todos los datos listos para generarlo.',
    type: 'info',
    action: 'Generar F104'
  }
]
