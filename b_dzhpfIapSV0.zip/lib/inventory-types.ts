export interface InventoryProduct {
  id: string
  name: string
  sku: string
  category: string
  averageCost: number
  quantity: number
  minStock: number
}

export interface InventoryMovement {
  id: string
  date: string
  type: 'purchase' | 'sale' | 'adjustment' | 'loss'
  productName: string
  quantity: number
  user: string
}

export type MovementType = 'purchase' | 'sale' | 'adjustment' | 'loss'
