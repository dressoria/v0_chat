import { Product } from './pos-types'

export const products: Product[] = [
  {
    id: '1',
    name: 'Vitamina C 1000mg',
    price: 12.99,
    stock: 45,
    image: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=200&h=200&fit=crop',
    category: 'vitaminas'
  },
  {
    id: '2',
    name: 'Omega 3 Fish Oil',
    price: 18.50,
    stock: 32,
    image: 'https://images.unsplash.com/photo-1559181567-c3190ca9959b?w=200&h=200&fit=crop',
    category: 'suplementos'
  },
  {
    id: '3',
    name: 'Proteína Whey 2kg',
    price: 45.00,
    stock: 18,
    image: 'https://images.unsplash.com/photo-1593095948071-474c5cc2989d?w=200&h=200&fit=crop',
    category: 'suplementos'
  },
  {
    id: '4',
    name: 'Crema Hidratante',
    price: 24.99,
    stock: 56,
    image: 'https://images.unsplash.com/photo-1570194065650-d99fb4b38b15?w=200&h=200&fit=crop',
    category: 'cuidado-piel'
  },
  {
    id: '5',
    name: 'Sérum Vitamina E',
    price: 32.00,
    stock: 28,
    image: 'https://images.unsplash.com/photo-1608248543803-ba4f8c70ae0b?w=200&h=200&fit=crop',
    category: 'cuidado-piel'
  },
  {
    id: '6',
    name: 'Colágeno Hidrolizado',
    price: 28.50,
    stock: 40,
    image: 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=200&h=200&fit=crop',
    category: 'suplementos'
  },
  {
    id: '7',
    name: 'Multivitamínico',
    price: 15.99,
    stock: 65,
    image: 'https://images.unsplash.com/photo-1550572017-edd951aa8f72?w=200&h=200&fit=crop',
    category: 'vitaminas'
  },
  {
    id: '8',
    name: 'Protector Solar SPF50',
    price: 19.99,
    stock: 42,
    image: 'https://images.unsplash.com/photo-1556227702-d1e4e7b5c232?w=200&h=200&fit=crop',
    category: 'cuidado-piel'
  },
  {
    id: '9',
    name: 'Magnesio 400mg',
    price: 11.50,
    stock: 55,
    image: 'https://images.unsplash.com/photo-1587854692152-cbe660dbde88?w=200&h=200&fit=crop',
    category: 'vitaminas'
  },
  {
    id: '10',
    name: 'BCAA Aminoácidos',
    price: 35.00,
    stock: 22,
    image: 'https://images.unsplash.com/photo-1579722821273-0f6c7d44362f?w=200&h=200&fit=crop',
    category: 'suplementos'
  },
  {
    id: '11',
    name: 'Crema Anti-edad',
    price: 42.00,
    stock: 15,
    image: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?w=200&h=200&fit=crop',
    category: 'cuidado-piel'
  },
  {
    id: '12',
    name: 'Zinc 50mg',
    price: 9.99,
    stock: 70,
    image: 'https://images.unsplash.com/photo-1631390169999-1d1b4b1c2c95?w=200&h=200&fit=crop',
    category: 'vitaminas'
  }
]
